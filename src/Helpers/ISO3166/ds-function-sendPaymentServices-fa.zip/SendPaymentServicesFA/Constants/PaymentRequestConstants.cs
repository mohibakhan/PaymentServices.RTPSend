﻿namespace SendPaymentServicesFA.Constants;

public static class PaymentRequestConstants
{
    public const string DocumentType = "CreatePayment";
    public const string DocumentSubTypeTabaPay = "TabaPay";
    public const string DocumentSubTypeVolante = "VolPay";
    public const string DocumentSubTypeStripe = "Stripe";
    public const string TransactionCompleted = "Completed"; 
    public const string TransactionRejectedNSF = "Insufficient Funds"; 
    public const string TransactionRejected = "Transaction rejected"; 
    public const string TransactionFailed = "Failed";
    public const string SuccessServiceBusSubject = "CreatePayment - Success";
    public const string FailureServiceBusSubject = "CreatePayment - Failure";
    public const string InternalErrorServiceBusSubject = "CreatePayment - Internal Error";
    public const string CreatePaymentTypePush = "push";
    public const string CreatePaymentAchOptions = "R";
    public const string CreatePaymentDefaultCurrency = "840";
    public const string PreValidatePaymentMsgSubject = "PreValidatePayment";
    public const string TabaPayComplete = "COMPLETED";
}