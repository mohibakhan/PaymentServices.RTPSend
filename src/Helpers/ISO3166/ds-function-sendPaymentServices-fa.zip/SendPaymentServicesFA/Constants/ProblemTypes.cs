﻿namespace SendPaymentServicesFA.Constants;

public static class ProblemTypes
{
    public const string Base = "evolve:digital:paas:createpayment:";
}