﻿using System;

namespace SendPaymentServicesFA.Constants;

public static class ValidPrefundEventConstants
{
    public static readonly Array ValidEvents = new[] 
           {
                PrefundLedgerConstants.SUCCESS,
                PrefundLedgerConstants.FAILURE,
                PrefundLedgerConstants.ACTION_REQUIRED,
                PrefundLedgerConstants.TMS_ACTION_REQUIRED,
                PrefundLedgerConstants.ACCOUNT_ACTION_REQUIRED
            };
}
