﻿namespace SendPaymentServicesFA.Constants;

public static class PrefundLedgerConstants
{
    //public const string SUCCESS = "KYCCompleted";

    public const string FAILURE = "KYCFailed";

    public const string ACTION_REQUIRED = "KYCActionRequired";

    public const string TMS_ACTION_REQUIRED = "TMSActionRequired";

    public const string SUCCESS = "TMSCompleted";

    public const string ACCOUNT_ACTION_REQUIRED = "AccountActionRequired";

    public const string INSUFFICIENT_FUNDS = "Insufficient Funds";

    public const string INSUFFICIENT_FUNDS_ERROR_MESSAGE = "Internal transfer failed. NSF on account. Make sure the provided information is correct.";

    public const string CYCLIC_DEPENDENCY_DETECTED = "cyclic dependency detected";

    public const string TRANSACTION_COMPLETED = "TransactionCompleted";

    public static readonly string[] ValidEvents =
           [
                SUCCESS,
                FAILURE,
                ACTION_REQUIRED,
                TMS_ACTION_REQUIRED,
                ACCOUNT_ACTION_REQUIRED
            ];
}