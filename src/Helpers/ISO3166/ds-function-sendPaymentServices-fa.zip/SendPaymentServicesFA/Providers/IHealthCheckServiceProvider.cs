﻿using System.Threading.Tasks;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace SendPaymentServicesFA.Providers;

public interface IHealthCheckServiceProvider
{
    /// <summary>
    /// Runs all health checks in the application and returns the aggregated status
    /// </summary>
    /// <returns>A <see cref="Task"/> which will complete when all the health checks have been run, yeilding a <see cref="HealthReport"/> containing the results</returns>
    Task<HealthReport> GetHealthAsync();
}