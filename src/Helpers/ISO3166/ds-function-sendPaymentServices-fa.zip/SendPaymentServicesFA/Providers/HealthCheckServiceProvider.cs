﻿using System.Threading.Tasks;
using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace SendPaymentServicesFA.Providers;

[ExcludeFromCodeCoverage]
public class HealthCheckServiceProvider : IHealthCheckServiceProvider
{
    private readonly HealthCheckService _healthCheckService;

    /// <summary>
    /// Initialize a new instance of the <see cref="HealthCheckServiceProvider"/> class
    /// </summary>
    /// <param name="healthCheckService">Health check service</param>
    public HealthCheckServiceProvider(HealthCheckService healthCheckService)
    {
        _healthCheckService = healthCheckService;
    }

    public async Task<HealthReport> GetHealthAsync()
    {
        return await _healthCheckService.CheckHealthAsync();
    }
}