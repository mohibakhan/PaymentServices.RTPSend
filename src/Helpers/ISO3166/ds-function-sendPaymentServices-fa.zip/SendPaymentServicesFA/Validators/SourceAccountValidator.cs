﻿using FluentValidation;
using Evolve.Digital.Shared.Models.Payments;

namespace SendPaymentServicesFA.Validators;

public class SourceAccountValidator : AbstractValidator<SourceAccount>
{
    public SourceAccountValidator()
    {
        // Rule for account number
        RuleFor(x => x.AccountNumber)
            .Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .Custom((x, context) =>
             {
                 if ((!(ulong.TryParse(x, out ulong value)) || value < 0))
                 {
                     context.AddFailure($"{x} is not a valid account number");
                 }
             });

        // Rule for account name
        RuleFor(x => x.Name)
            .Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .WithMessage("Source Account name is required");

        //RuleFor(x => x.Name.First)
        //   .NotNull()
        //   .SetValidator(new AccountNameValidator());

        // Rule for routing number
        RuleFor(x => x.RoutingNumber)
            .Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .Custom((x, context) =>
             {
                 if ((!(ulong.TryParse(x, out ulong value)) || value < 0))
                 {
                     context.AddFailure($"{x} is not a valid Routing number");
                 }
             });

        // Rule for account type
        RuleFor(x => x.AccountType)
            .NotEmpty()
            .NotNull()
            .IsEnumName(typeof(AccountType))
            .WithMessage("Invalid Source AccountType is required and can be one of the following values: S, C, A, B, L");

        /*Debtor Id other is not required*/
        //RuleFor(x => x.DebtorIdOther)
        //    .Cascade(CascadeMode.Stop)
        //    .NotNull()
        //    .NotEmpty()
        //    .WithMessage("Debtor Other Id is required");
    }
}
