﻿using FluentValidation;
using Evolve.Digital.Shared.Models.Payments;

namespace SendPaymentServicesFA.Validators;

public class DestinationAccountValidator : AbstractValidator<DestinationAccount>
{
    public DestinationAccountValidator()
    {
        // Rule for account number
        RuleFor(x => x.AccountNumber)
            .Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .Custom((x, context) =>
             {
                 if ((!(ulong.TryParse(x, out ulong value)) || value < 0))
                 {
                     context.AddFailure($"{x} is not a valid account number");
                 }
             });

        // Rule for account name
        RuleFor(x => x.Name)
            .Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .WithMessage("Destination Account name is required");

        // Rule for routing number
        RuleFor(x => x.RoutingNumber)
            .Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .Custom((x, context) =>
             {
                 if ((!(ulong.TryParse(x, out ulong value)) || value < 0))
                 {
                     context.AddFailure($"{x} is not a valid Routing number");
                 }
             });

        // Rule for account type
        RuleFor(x => x.AccountType)
            .NotEmpty()
            .NotNull()
            .IsEnumName(typeof(AccountType))
            .WithMessage("Invalid Destination Account type is required and can be one of the following values: S, C, A, B, L");

        // Commenting this rule to because Volante can't fix things

        //RuleFor(x => x.CreditorIdOther)
        //    .Cascade(CascadeMode.Stop)
        //    .NotNull()
        //    .NotEmpty()
        //    .WithMessage("Creditor Other Id is required");
    }
}
