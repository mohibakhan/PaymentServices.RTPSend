﻿using FluentValidation;
using Evolve.Digital.Shared.Models.Payments;

namespace SendPaymentServicesFA.Validators;

public class BasicPaymentRequestValidator : AbstractValidator<BasicPaymentRequest>
{
    public BasicPaymentRequestValidator()
    {
        // Payment Reference rule
        RuleFor(x => x.PaymentReference)
            .Cascade(CascadeMode.Stop)
            .NotNull().WithMessage("PaymentReference cannot be null")
            .NotEmpty().WithMessage("PaymentReference cannot be empty");

        // Source AccountId rule
        //RuleFor(x => x.SourceAccountId)

        // Rule for ammount
        RuleFor(x => x.Amount)
            .Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .MaximumLength(18)
            .Custom((x, context) =>
            {
                if ((!(double.TryParse(x, out double value)) || value < 0))
                {
                    context.AddFailure($"{x} is not a valid amount or less than 0");
                }
            });

        // Rule for payment currency
        //RuleFor(x => x.PaymentCurrency).

        // Rule for source currency
        //RuleFor(x => x.SourceCurrency).

        //Rule for Source Account
        RuleFor(m => m.SourceAccount).NotNull().SetValidator(new SourceAccountValidator())
            .When(m => string.IsNullOrWhiteSpace(m.SourceAccountId))
            .WithMessage("SourceAccount or SourceAccountId is required");

        When(s => s.SoftDescriptor != null, () =>
        {
            RuleFor(s => s.SoftDescriptor.Name)
             .Cascade(CascadeMode.Stop)
                .NotNull()
                .NotEmpty()
                .WithMessage("Soft Descriptor 'Name' is required and should not be empty");

            RuleFor(s => s.SoftDescriptor.Address)
                .Cascade(CascadeMode.Stop)
                .NotNull()
                .NotEmpty()
                .WithMessage("Soft Descriptor 'Address' is required")
                .DependentRules(() =>
                {
                    RuleFor(s => s.SoftDescriptor.Address)
                        .SetValidator(new SoftDescriptorAddressValidator());
                });

            When(s => s.SoftDescriptor.Phone != null, () =>
            {
                RuleFor(s => s.SoftDescriptor.Phone.Number)
                    .Cascade(CascadeMode.Stop)
                    .NotEmpty()
                    .NotNull()
                    .WithMessage("Soft Descriptor 'Phone' is required");
            });
        });



        //Rule for Source Account
        //RuleFor(x => x.SourceAccount)
        //    .NotNull()
        //    .SetValidator(new SourceAccountValidator());

        //Rule for Source Account Name
        //RuleFor(x => x.SourceAccount.Name)
        //    .NotNull()
        //    .SetValidator(new AccountNameValidator());

        //Rule for Destination Account
        RuleFor(x => x.DestinationAccount).NotNull().SetValidator(new DestinationAccountValidator())
            .When(x => string.IsNullOrWhiteSpace(x.DestinationAccountId))
            .WithMessage("DestinationAccount or DestinationAccountId is required"); ;
    }
}
