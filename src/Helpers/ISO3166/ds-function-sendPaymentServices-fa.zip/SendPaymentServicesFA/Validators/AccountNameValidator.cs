﻿using FluentValidation;
using Evolve.Digital.Shared.Models.Payments;

namespace SendPaymentServicesFA.Validators;

public class AccountNameValidator : AbstractValidator<AccountName>
{
    public AccountNameValidator()
    {
        // Rule for account name
        RuleFor(x => x.First)
            .Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .WithMessage("Source Account first name is required");

        // Rule for account name
        RuleFor(x => x.Last)
            .Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .WithMessage("Source Account last name is required");
    }
}
