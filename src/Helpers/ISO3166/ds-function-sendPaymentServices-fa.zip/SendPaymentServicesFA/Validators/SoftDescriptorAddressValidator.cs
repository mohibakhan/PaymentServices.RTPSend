﻿using FluentValidation;
using Evolve.Digital.Shared.Models.Payments;
using System.Collections.Generic;
using Evolve.Digital.Shared.Helpers.ISO3166;
using System.Threading.Tasks;
using System.Threading;
using System;
using System.Linq;

namespace SendPaymentServicesFA.Validators;
public class SoftDescriptorAddressValidator : AbstractValidator<Address>
{
    public SoftDescriptorAddressValidator()
    {
        // Rule for address
        RuleFor(x => x.AddressLines)
            .Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .WithMessage("Address is required");

        // Rule for city
        RuleFor(x => x.City)
            .Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .WithMessage("City is required");

        // Rule for county
        RuleFor(x => x.County)
            .Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .WithMessage("County is required")
            .Length(3).WithMessage("County code must be exactly 3 characters long");

        // Rule for state
        RuleFor(x => x.StateCode)
            .Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .WithMessage("state code is required")
            .Length(2).WithMessage("State code must be exactly 2 characters long");

        // Rule for zip code
        RuleFor(x => x.PostalCode)
            .Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .WithMessage("postal code is required");

        // Rule for country
        RuleFor(x => x.CountryISOCode)
            .Cascade(CascadeMode.Stop)
            .NotNull()
            .NotEmpty()
            .WithMessage("country code is required")
            .Length(3).WithMessage("Country code must be exactly 3 characters long")
            .MustAsync(BeAValidIso3166NumericCode).WithMessage("Invalid ISO 3166-1 numeric country code");
    }

    private async Task<bool> BeAValidIso3166NumericCode(string countryCode, CancellationToken token)
    {
        var countryCodes = await GetCountryCodesAsync();
        return countryCodes.Contains(countryCode);
    }

    private async Task<HashSet<string>> GetCountryCodesAsync()
    {
        var countryList = await CountryCodeHelper.GetListAsync();
        return new HashSet<string>(countryList.Select(c => c.Code));
    }
}
