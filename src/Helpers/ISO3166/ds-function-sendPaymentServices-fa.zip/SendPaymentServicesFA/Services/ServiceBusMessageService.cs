﻿using Newtonsoft.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SendPaymentServicesFA.Models;
using Evolve.Digital.Shared.Models;
using SendPaymentServicesFA.Settings;
using SendPaymentServicesFA.Interface.Services;
using SendPaymentServicesFA.Interface.Adapters;

namespace SendPaymentServicesFA.Services;
public class ServiceBusMessageService : IServiceBusMessageService
{
    private readonly AppSettings _appSettings;
    private readonly IServiceBusAdapter _serviceBusAdapter;
    private readonly ILogger<ServiceBusMessageService> _logger;

    public ServiceBusMessageService(
        IOptions<AppSettings> appSettings,
        IServiceBusAdapter serviceBusAdapter,
        ILogger<ServiceBusMessageService> logger)
    {
        _appSettings = appSettings.Value;
        _serviceBusAdapter = serviceBusAdapter;
        _logger = logger;
    }

    public async Task SendMessageToServiceBusAsync(ServiceBusContentModel serviceBusMessage, string subject)
    {
        var content = JsonConvert.SerializeObject(serviceBusMessage);
        _logger.LogInformation($"Sending message to Service Bus: {content}");
        var serviceBusRequest = new ServiceBusRequest()
        {
            Content = content,
            Subject = subject,
            QueueName = _appSettings?.SERVICE_BUS_TOPIC_NAME
        };

        _logger.LogInformation($"Message sent to service bus");

        // Send message to service bus queue
        await _serviceBusAdapter.SendMessage(serviceBusRequest);
    }
}
