﻿using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using SendPaymentServicesFA.Interface;
using SendPaymentServicesFA.Models.Request;
using Evolve.Digital.Shared.Models.Payments;
using SendPaymentServicesFA.Interface.Adapters;
using SendPaymentServicesFA.Interface.Services;

namespace SendPaymentServicesFA.Services;

public class PrefundEventProcessor : IPrefundEventProcessor
{
    private readonly Dictionary<string, IEventHandler> _eventHandlers;
    private readonly ILogger<PrefundEventProcessor> _logger;

    public PrefundEventProcessor(ILogger<PrefundEventProcessor> logger, IPaymentCosmosDBAdapter cosmosdB)
    {
        _eventHandlers = new Dictionary<string, IEventHandler>();
        _logger = logger;

    }

    public void RegisterEventHandler(string eventName, IEventHandler handler)
    {
        _eventHandlers[eventName] = handler;
    }

    public async Task<bool> ProcessEventAsync(RtpValidateEvent ev, EvolvePaymentRequest evolvePaymentRequest)
    {
        _logger.LogInformation($"Processing event: {ev.Event}");
        if (_eventHandlers.TryGetValue(ev.Event, out IEventHandler handler))
        {
            var result = await handler.HandleEventAsync(ev, evolvePaymentRequest);
            return result;
        }
        else
        {
            _logger.LogInformation($"No handler found for event: {ev.Event}");
            return false;
        }
    }
}