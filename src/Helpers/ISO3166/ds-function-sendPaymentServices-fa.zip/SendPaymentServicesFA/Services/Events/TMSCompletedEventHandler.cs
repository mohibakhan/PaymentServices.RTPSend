﻿using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Logging;
using SendPaymentServicesFA.Settings;
using SendPaymentServicesFA.Models.Request;
using Evolve.Digital.Shared.Models.Payments;
using SendPaymentServicesFA.Interface.Factory;
using SendPaymentServicesFA.Interface.Adapters;

namespace SendPaymentServicesFA.Services.Events;

public class TMSCompletedEventHandler : BaseEventHandler
{
    private readonly AppSettings _appSettings;
    private readonly IPaymentHandlerFactorySelector _factorySelector;

    public TMSCompletedEventHandler(
        IPaymentCosmosDBAdapter cosmosdB,
        ILogger<BaseEventHandler> logger,
        IServiceBusAdapter serviceBusAdapter,
        IOptions<AppSettings> appSettings,
        IPaymentHandlerFactorySelector factorySelector) : base(logger, serviceBusAdapter, cosmosdB)
    {
        _appSettings = appSettings.Value;
        _factorySelector = factorySelector;
    }

    public override string ServiceBusQueueName => _appSettings.SERVICE_BUS_QUEUE_NAME;

    public override async Task<bool> HandleEventAsync(RtpValidateEvent ev, EvolvePaymentRequest cosmosPaymentItem)
    {
        _logger.LogInformation($"Processing event {ev.Event} in event handler: {nameof(TMSCompletedEventHandler)}");

        IPaymentHandlerFactory factory = _factorySelector.GetFactory(cosmosPaymentItem.DocumentSubType.ToLower());

        // Create payment handler dynamically using the factory
        IPaymentHandler paymentHandler = factory.CreatePaymentHandler();
        var response = await paymentHandler.ProcessPayment(cosmosPaymentItem);
        return true;
    }
}