﻿using System.Threading.Tasks;
using SendPaymentServicesFA.Models;
using Microsoft.Extensions.Logging;
using SendPaymentServicesFA.Helpers;
using SendPaymentServicesFA.Interface;
using SendPaymentServicesFA.Models.Request;
using Evolve.Digital.Shared.Models.Payments;
using SendPaymentServicesFA.Interface.Adapters;

namespace SendPaymentServicesFA.Services.Events;

public abstract class BaseEventHandler : IEventHandler
{
    protected readonly ILogger<BaseEventHandler> _logger;
    protected readonly IServiceBusAdapter _serviceBusAdapter;
    protected readonly IPaymentCosmosDBAdapter _cosmosdB;


    public BaseEventHandler(ILogger<BaseEventHandler> logger, IServiceBusAdapter serviceBusAdapter, IPaymentCosmosDBAdapter cosmosdB)
    {
        _logger = logger;
        _serviceBusAdapter = serviceBusAdapter;
        _cosmosdB = cosmosdB;

    }
    public abstract string ServiceBusQueueName { get; }

    public abstract Task<bool> HandleEventAsync(RtpValidateEvent ev, EvolvePaymentRequest evolvePaymentRequest);

    protected async Task SendMessageToServiceBusAsync(string content, string subject)
    {
        _logger.LogInformation($"Sending message to Service Bus: {content}");
        var serviceBusRequest = new ServiceBusRequest()
        {
            Content = content,
            Subject = subject,
            QueueName = ServiceBusQueueName
        };

        _logger.LogInformation($"Message sent to service bus");

        // Send message to service bus queue
        await _serviceBusAdapter.SendMessage(serviceBusRequest);
    }

    protected async Task<EvolvePaymentRequest> PatchTransactionStatusAsync(RequestStage stage, RequestStatus status, string additionalInfo, EvolvePaymentRequest request)
    {
        // Patch cosmos item
        var patchOperationStatus = EvolvePaymentRequestHelper.GetStatusPatchOperation(stage, status, additionalInfo);

        return await _cosmosdB.PatchItemAsync(request, patchOperationStatus);
    }
}