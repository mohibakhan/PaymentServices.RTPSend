﻿using System;
using Newtonsoft.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Logging;
using SendPaymentServicesFA.Settings;
using SendPaymentServicesFA.Constants;
using SendPaymentServicesFA.Exceptions;
using SendPaymentServicesFA.Models.Request;
using Evolve.Digital.Shared.Models.Payments;
using SendPaymentServicesFA.Interface.Adapters;
using SendPaymentServicesFA.Helpers;

namespace SendPaymentServicesFA.Services.Events;

public class KYCFailedEventHandler : BaseEventHandler
{
    private readonly AppSettings _appSetttings;

    public KYCFailedEventHandler(
        IPaymentCosmosDBAdapter cosmosdB,
        ILogger<BaseEventHandler> logger,
        IServiceBusAdapter serviceBusAdapter,
        IOptions<AppSettings> appSettings ) : base(logger, serviceBusAdapter, cosmosdB)
    {
        _appSetttings = appSettings.Value;
    }

    public override string ServiceBusQueueName => _appSetttings.SERVICE_BUS_QUEUE_NAME;

    public override async Task<bool> HandleEventAsync(RtpValidateEvent ev, EvolvePaymentRequest cosmosPaymentItem)
    {
        try
        {
            _logger.LogInformation($"Processing event {ev.Event} in event handler: {nameof(KYCFailedEventHandler)}");

            await PatchTransactionStatusAsync(RequestStage.FRAUDSANCTIONCHECK, RequestStatus.FAILED,
            $"Payment Rejected - Transaction could not be completed. Event {ev.Event}", cosmosPaymentItem);

            cosmosPaymentItem.Status = RequestStatus.FAILED.ToString();

            // Send message to service bus
            var serviceBusContent = ServiceBusHelper.CreateServiceBusMessage(cosmosPaymentItem, false,
                new { Reason = PaymentRequestConstants.TransactionFailed, ev.Event }, null);
            await SendMessageToServiceBusAsync(JsonConvert.SerializeObject(serviceBusContent), PaymentRequestConstants.FailureServiceBusSubject);

            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError($"An error occured in {nameof(AccountActionRequiredEventHandler)} while processing event: {ev.Event} for evolveId {cosmosPaymentItem.EvolveId} ");
            throw new EventHandlerException(ex.Message);
        }
    }
}