﻿using System;
using Newtonsoft.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Logging;
using SendPaymentServicesFA.Helpers;
using SendPaymentServicesFA.Settings;
using SendPaymentServicesFA.Constants;
using SendPaymentServicesFA.Interface;
using SendPaymentServicesFA.Exceptions;
using SendPaymentServicesFA.Models.Request;
using Evolve.Digital.Shared.Models.Payments;
using SendPaymentServicesFA.Interface.Adapters;

namespace SendPaymentServicesFA.Services.Events;

public class AccountActionRequiredEventHandler : BaseEventHandler
{
    private readonly AppSettings _appSetttings;
    private readonly IEvolvePaymentRequestHelper _evolvePaymentRequestHelper;

    public AccountActionRequiredEventHandler(
        IPaymentCosmosDBAdapter cosmosdB,
        ILogger<BaseEventHandler> logger,
        IServiceBusAdapter serviceBusAdapter,
        IOptions<AppSettings> appSettings,
        IEvolvePaymentRequestHelper evolvePaymentRequestHelper) : base(logger, serviceBusAdapter, cosmosdB)
    {
        _appSetttings = appSettings.Value;
        _evolvePaymentRequestHelper = evolvePaymentRequestHelper;

    }

    public override string ServiceBusQueueName => _appSetttings.SERVICE_BUS_QUEUE_NAME;

    public override async Task<bool> HandleEventAsync(RtpValidateEvent ev, EvolvePaymentRequest cosmosPaymentItem)
    {
        try
        {
            _logger.LogInformation($"Processing event {ev.Event} in event handler: {nameof(AccountActionRequiredEventHandler)}");

            if (ev.Description == PrefundLedgerConstants.INSUFFICIENT_FUNDS)
            {
                // Check if the document has already failed with insufficient funds
                var containsStatus = _evolvePaymentRequestHelper.ContainsAdditionalInfo(cosmosPaymentItem.StatusHistory, PrefundLedgerConstants.INSUFFICIENT_FUNDS);

                // If string contains insufficient funds, do not process further
                if (containsStatus)
                    return true;
            }

            string additionalInfo = (ev.Description == PrefundLedgerConstants.INSUFFICIENT_FUNDS)
                                                                    ? PrefundLedgerConstants.INSUFFICIENT_FUNDS :
                                                                      PaymentRequestConstants.TransactionRejected;
            await PatchTransactionStatusAsync(RequestStage.FRAUDSANCTIONCHECK, RequestStatus.FAILED,
            $"{additionalInfo}. Event {ev.Event}", cosmosPaymentItem);

            cosmosPaymentItem.Status = RequestStatus.FAILED.ToString();

            // Send message to service bus
            object sbAdditionalInfo = (ev.Description == PrefundLedgerConstants.INSUFFICIENT_FUNDS)
                                                                    ? new { Reason = PaymentRequestConstants.TransactionRejectedNSF, ev.Event } :
                                                                      new { Reason = PaymentRequestConstants.TransactionRejected, ev.Event };

            var serviceBusContent = ServiceBusHelper.CreateServiceBusMessage(cosmosPaymentItem, false, sbAdditionalInfo, null);

            await SendMessageToServiceBusAsync(JsonConvert.SerializeObject(serviceBusContent), PaymentRequestConstants.FailureServiceBusSubject);

            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError($"An error occured in {nameof(AccountActionRequiredEventHandler)} while processing event: {ev.Event} for evolveId {cosmosPaymentItem.EvolveId} ");
            throw new EventHandlerException(ex.Message);
        }
    }
}