﻿using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Evolve.Digital.Core.Api;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SendPaymentServicesFA.Settings;
using SendPaymentServicesFA.Models.Request;
using SendPaymentServicesFA.Interface.Services;

namespace SendPaymentServicesFA.Services;

public class ValidatePaymentService : ApiAdapterBase, IValidatePaymentService
{
    private readonly AppSettings _appSettings;
    private readonly ILogger<ValidatePaymentService> _logger;
    private HeaderEntry _validatePaymentHostKeyHeader;

    protected override string BaseAddress { get { return _appSettings.VALIDATE_PAYMENT_URL; } }
    private HeaderEntry ValidatePaymentHostKeyHeader => _validatePaymentHostKeyHeader ??= new HeaderEntry("x-functions-key", _appSettings.VALIDATE_PAYMENT_HOSTKEY_HEADER);

    public ValidatePaymentService(IHttpClientFactory clientFactory, IOptions<AppSettings> appSettings, ILogger<ValidatePaymentService> logger) : base(clientFactory)
    {
        _appSettings = appSettings.Value;
        _logger = logger;
    }

    public async Task<HttpResponseMessage> ValidatePaymentAsync(RtpValidateEvent eventNotification)
    {
        CancellationToken ct = CancellationToken.None;
        try
        {
            return await base.PostAsync("", eventNotification, ct, ValidatePaymentHostKeyHeader);
        }
        catch (ServiceException ex)
        {
            // ServiceException contains the status code, response headers, and response body
            _logger.LogError("Error calling the API: status code {statusCode} and error message {errorMessage}.", ex.StatusCode, ex.ResponseMessage);

            // Return null
            return null;
        }
    }
}