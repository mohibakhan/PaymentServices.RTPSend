﻿using System;
using System.Text;
using Newtonsoft.Json;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SendPaymentServicesFA.Helpers;
using SendPaymentServicesFA.Settings;
using SendPaymentServicesFA.Constants;
using SendPaymentServicesFA.Interface;
using SendPaymentServicesFA.Exceptions;
using SendPaymentServicesFA.Models.Request;
using SendPaymentServicesFA.Models.Response;
using Evolve.Digital.Shared.Models.Payments;
using SendPaymentServicesFA.Interface.Factory;
using SendPaymentServicesFA.Interface.Adapters;
using SendPaymentServicesFA.Interface.Services;

namespace SendPaymentServicesFA.Services.Factory;

public class TabaPayHandler : IPaymentHandler
{
    private readonly ILogger<TabaPayHandler> _logger;
    private readonly AppSettings _appSettings;
    private readonly IPaymentCosmosDBAdapter _cosmosdB;
    private readonly IPrefundLedgerService _prefundLedgerService;
    private readonly IEvolvePaymentRequestHelper _helper;
    private readonly IServiceBusMessageService _serviceBusMessageService;
    private readonly IApiUserConfigCosmosAdapter _apiConfig;
    private static readonly HttpClient httpClient = new HttpClient();

    public TabaPayHandler(ILogger<TabaPayHandler> logger,
                          IHttpClientFactory clientFactory,
                          IOptions<AppSettings> appSettings,
                          IPaymentCosmosDBAdapter cosmosdB,
                          IPrefundLedgerService prefundLedgerService,
                          IEvolvePaymentRequestHelper helper,
                          IServiceBusMessageService serviceBusMessageService,
                          IApiUserConfigCosmosAdapter apiConfig)
    {
        _logger = logger;
        _appSettings = appSettings.Value;
        _cosmosdB = cosmosdB;
        _prefundLedgerService = prefundLedgerService;
        _helper = helper;
        _serviceBusMessageService = serviceBusMessageService;
        _apiConfig = apiConfig;
    }

    public async Task<bool> ProcessPayment(EvolvePaymentRequest cosmosPaymentItem)
    {
        _logger.LogInformation($"TabaPay Handler selected for evolve Id {cosmosPaymentItem.EvolveId}");
        try
        {
            var tabapayRequest = TabaPayRequestHelper.ConvertEvolveToTabaPayRequest(cosmosPaymentItem);

            string clientId = cosmosPaymentItem.ClientId;
            string merchantId = cosmosPaymentItem.MerchantId;
            var apiUserConfigResponse = await _apiConfig.GetApiUserConfigAsync(clientId, merchantId);
            string subscriptionKey = apiUserConfigResponse.SubscriptionKey;

            var response = await SendTransactionAsync(tabapayRequest, clientId, merchantId, subscriptionKey);

            var msg = await response?.Content?.ReadAsStringAsync();
            _logger.LogInformation($"Message content from TabaPay response {msg}");

            var tabaPayResponse = JsonConvert.DeserializeObject<Models.Response.TabaPayResponse>(msg);

            bool isSuccess = false;
            if(Convert.ToInt16(response.StatusCode) == StatusCodes.Status200OK 
                && tabaPayResponse.Status == PaymentRequestConstants.TabaPayComplete 
                && tabaPayResponse.Sc == StatusCodes.Status200OK)
            {
                _logger.LogWarning($"Tabapay send transaction successful");
                isSuccess = true;
            }
            else
            {
                _logger.LogWarning($"Tabapay send transaction unsuccessful");
            }

            // Update cosmos db with status and transactionID
            await PatchTransactionStatusAsync(
                RequestStage.TABAPAY,
                isSuccess ? RequestStatus.COMPLETED : RequestStatus.FAILED,
                msg,
                cosmosPaymentItem);

            if (isSuccess)
            {
                _logger.LogInformation($"Updating cosmos Db and sending status to prefund status");

                cosmosPaymentItem = await PatchTransactionTabaPayAsync(tabaPayResponse, tabapayRequest.ReferenceId, cosmosPaymentItem);

                // Send Payment Status
                var businessPaymentRequest = _helper.ConvertToBusinessDocument(cosmosPaymentItem);
                await _prefundLedgerService.SendPaymentStatus(businessPaymentRequest);
            }

            var addInfo = new
            {
                cosmosPaymentItem.PaymentReference,
                Status = isSuccess ? PaymentRequestConstants.TransactionCompleted : PaymentRequestConstants.TransactionFailed,
                Message = msg
            };

            // Send message to service bus
            cosmosPaymentItem.Status = isSuccess ? RequestStatus.COMPLETED.ToString() : RequestStatus.FAILED.ToString();
            var serviceBusMessage = ServiceBusHelper.CreateServiceBusMessage(cosmosPaymentItem, isSuccess, addInfo, null);

            await _serviceBusMessageService.SendMessageToServiceBusAsync(
                serviceBusMessage,
                isSuccess ? PaymentRequestConstants.SuccessServiceBusSubject : PaymentRequestConstants.FailureServiceBusSubject);

            return true;
        }
        catch (Exception ex)
        {
            cosmosPaymentItem = await PatchTransactionStatusAsync(RequestStage.TABAPAY, RequestStatus.FAILED, $"Error: {ex.Message}", cosmosPaymentItem);
            var addInfo = new
            {
                cosmosPaymentItem.PaymentReference,
                Status = PaymentRequestConstants.TransactionFailed,
                Message = $"TabaPay Exception: {ex.Message}"
            };
            var serviceBusMessage = ServiceBusHelper.CreateServiceBusMessage(cosmosPaymentItem, false, addInfo, null);
            await _serviceBusMessageService.SendMessageToServiceBusAsync(serviceBusMessage, PaymentRequestConstants.FailureServiceBusSubject);
            throw new TabaPayProcessingException(ex.Message);
        }
    }

    public async Task<HttpResponseMessage> SendTransactionAsync(TabaPayRequest tabaPayRequest, string clientId, string merchantId, string subscriptionKey)
    {
        var content = new StringContent(JsonConvert.SerializeObject(tabaPayRequest), Encoding.UTF8, "application/json");
        _logger.LogInformation($"Request sent to tabapay: {JsonConvert.SerializeObject(tabaPayRequest)}");
        httpClient.DefaultRequestHeaders.Clear();
        httpClient.DefaultRequestHeaders.Add("x-Client-Id", clientId);
        httpClient.DefaultRequestHeaders.Add("x-merchant-id", merchantId);
        httpClient.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", subscriptionKey);
        HttpResponseMessage response = await httpClient.PostAsync(_appSettings.TABAPAY_SEND_URL, content);
        _logger.LogInformation($"Raw response from TabaPay: {JsonConvert.SerializeObject(response)}");
        return response;
    }

    private async Task<EvolvePaymentRequest> PatchTransactionTabaPayAsync(Models.Response.TabaPayResponse tabaPayResponse, string referenceId, EvolvePaymentRequest request)
    {
        var patchOperation = EvolvePaymentRequestHelper.GetTabaPaypatchoperation(tabaPayResponse.TransactionId, referenceId, tabaPayResponse.NetworkId);
        return await _cosmosdB.PatchItemAsync(request, patchOperation);
    }

    private async Task<EvolvePaymentRequest> PatchTransactionStatusAsync(RequestStage stage, RequestStatus status, string additionalInfo, EvolvePaymentRequest request)
    {
        // Patch cosmos item
        var patchOperationStatus = EvolvePaymentRequestHelper.GetStatusPatchOperation(stage, status, additionalInfo);
        return await _cosmosdB.PatchItemAsync(request, patchOperationStatus);
    }
}