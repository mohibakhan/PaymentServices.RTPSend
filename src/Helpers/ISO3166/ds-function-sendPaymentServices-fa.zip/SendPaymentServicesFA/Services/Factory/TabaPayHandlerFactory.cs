﻿using System.Net.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SendPaymentServicesFA.Settings;
using SendPaymentServicesFA.Interface;
using SendPaymentServicesFA.Interface.Adapters;
using SendPaymentServicesFA.Interface.Factory;
using SendPaymentServicesFA.Interface.Services;

namespace SendPaymentServicesFA.Services.Factory;

public class TabaPayHandlerFactory : IPaymentHandlerFactory
{
    private readonly ILogger<TabaPayHandler> _logger;
    private readonly IOptions<AppSettings> _appSettings;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IPaymentCosmosDBAdapter _cosmosdB;
    private readonly IPrefundLedgerService _prefundLedgerService;
    private readonly IEvolvePaymentRequestHelper _helper;
    private readonly IServiceBusMessageService _serviceBusMessageService;
    private readonly IApiUserConfigCosmosAdapter _apiConfig;

    public TabaPayHandlerFactory(
        IHttpClientFactory httpClientFactory, 
        ILogger<TabaPayHandler> logger, 
        IOptions<AppSettings> appSettings, 
        IPaymentCosmosDBAdapter cosmosdB,
        IPrefundLedgerService prefundLedgerServic,
        IEvolvePaymentRequestHelper helper,
        IServiceBusMessageService serviceBusMessageService,
        IApiUserConfigCosmosAdapter apiConfig)
    {
        _logger = logger;
        _appSettings = appSettings;
        _httpClientFactory = httpClientFactory;
        _cosmosdB = cosmosdB;
        _prefundLedgerService = prefundLedgerServic;
        _helper = helper;
        _serviceBusMessageService = serviceBusMessageService;
        _apiConfig = apiConfig;
    }
    public IPaymentHandler CreatePaymentHandler()
    {
        return new TabaPayHandler(_logger, _httpClientFactory, _appSettings, _cosmosdB, _prefundLedgerService, _helper, _serviceBusMessageService, _apiConfig);
    }
}