﻿using System.Linq;
using System.Collections.Generic;
using SendPaymentServicesFA.Exceptions;
using SendPaymentServicesFA.Interface.Factory;

namespace SendPaymentServicesFA.Services.Factory;

public class PaymentHandlerFactorySelector : IPaymentHandlerFactorySelector
{
    private readonly IDictionary<string, IPaymentHandlerFactory> _factories;

    public PaymentHandlerFactorySelector(IEnumerable<IPaymentHandlerFactory> factories)
    {
        _factories = factories.ToDictionary(factory => factory.GetType().Name.Replace("Factory", "").ToLower());
    }

    public IPaymentHandlerFactory GetFactory(string paymentType)
    {
        if (_factories.TryGetValue(paymentType.ToLower() + "handler", out var factory))
        {
            return factory;
        }

        throw new PaymentHandlerException($"Payment type '{paymentType}' is not supported.");
    }
}