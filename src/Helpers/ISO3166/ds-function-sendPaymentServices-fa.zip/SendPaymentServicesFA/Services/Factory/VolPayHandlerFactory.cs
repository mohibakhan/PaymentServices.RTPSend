﻿using System.Net.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SendPaymentServicesFA.Interface;
using SendPaymentServicesFA.Settings;
using SendPaymentServicesFA.Interface.Adapters;
using SendPaymentServicesFA.Interface.Factory;
using SendPaymentServicesFA.Interface.Services;

namespace SendPaymentServicesFA.Services.Factory;

public class VolPayHandlerFactory : IPaymentHandlerFactory
{
    private readonly ILogger<VolPayHandler> _logger;
    private readonly IOptions<AppSettings> _appSettings;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IPaymentCosmosDBAdapter _cosmosdB;
    private readonly IPrefundLedgerService _prefundLedgerService;
    private readonly IEvolvePaymentRequestHelper _helper;
    private readonly IServiceBusMessageService _serviceBusMessageService;

    public VolPayHandlerFactory(
        IHttpClientFactory httpClientFactory,
        ILogger<VolPayHandler> logger,
        IOptions<AppSettings> appSettings,
        IPaymentCosmosDBAdapter cosmosdB,
        IPrefundLedgerService prefundLedgerServic,
        IEvolvePaymentRequestHelper helper,
        IServiceBusMessageService serviceBusMessageService)
    {
        _logger = logger;
        _appSettings = appSettings;
        _httpClientFactory = httpClientFactory;
        _cosmosdB = cosmosdB;
        _prefundLedgerService = prefundLedgerServic;
        _helper = helper;
        _serviceBusMessageService = serviceBusMessageService;
    }
    public IPaymentHandler CreatePaymentHandler()
    {
        return new VolPayHandler(_logger, _httpClientFactory, _appSettings, _cosmosdB, _prefundLedgerService, _helper, _serviceBusMessageService);
    }
}