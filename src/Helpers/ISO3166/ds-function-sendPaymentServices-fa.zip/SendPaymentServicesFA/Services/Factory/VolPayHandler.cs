﻿using System;
using System.Net;
using System.Net.Http;
using Newtonsoft.Json;
using System.Threading;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;
using Evolve.Digital.Core.Api;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SendPaymentServicesFA.Models;
using SendPaymentServicesFA.Helpers;
using SendPaymentServicesFA.Settings;
using SendPaymentServicesFA.Constants;
using SendPaymentServicesFA.Interface;
using SendPaymentServicesFA.Exceptions;
using SendPaymentServicesFA.Models.Request;
using SendPaymentServicesFA.Models.Response;
using Evolve.Digital.Shared.Models.Payments;
using SendPaymentServicesFA.Interface.Factory;
using SendPaymentServicesFA.Interface.Adapters;
using SendPaymentServicesFA.Interface.Services;

namespace SendPaymentServicesFA.Services.Factory;

public class VolPayHandler : ApiAdapterBase, IPaymentHandler
{
    private readonly ILogger<VolPayHandler> _logger;
    private readonly AppSettings _appSettings;
    private readonly IPaymentCosmosDBAdapter _cosmosdB;
    private readonly IPrefundLedgerService _prefundLedgerService;
    private readonly IEvolvePaymentRequestHelper _helper;
    private readonly IServiceBusMessageService _serviceBusMessageService;

    protected override string BaseAddress { get { return _appSettings.VOLPAY_BASE_URL; } }
    protected override string BearerToken => base.BearerToken;
    protected override int TimeoutSeconds { get { return 60; } }

    public VolPayHandler(ILogger<VolPayHandler> logger,
                         IHttpClientFactory clientFactory,
                         IOptions<AppSettings> appSettings,
                         IPaymentCosmosDBAdapter cosmosDb,
                         IPrefundLedgerService prefundLedgerService,
                         IEvolvePaymentRequestHelper helper,
                         IServiceBusMessageService serviceBusMessageService) : base(clientFactory)
    {
        _logger = logger;
        _appSettings = appSettings.Value;
        _cosmosdB = cosmosDb;
        _prefundLedgerService = prefundLedgerService;
        _helper = helper;
        _serviceBusMessageService = serviceBusMessageService;
    }
    public async Task<bool> ProcessPayment(EvolvePaymentRequest cosmosPaymentItem)
    {
        _logger.LogInformation($"VolPay Handler selected for evolve Id {cosmosPaymentItem.EvolveId}");
        try
        {
            var volPayRequest = VolPayRequestHelper.ConvertEvolveToVolPayRequest(cosmosPaymentItem);
            var apiResponse = await SendTransactionAsync(volPayRequest);

            var msg = await apiResponse?.Content.ReadAsStringAsync();
            _logger.LogInformation($"Message content from VolPay response {msg}");

            var response = JsonConvert.DeserializeObject<VolPayResponse>(msg);

            bool isSuccess = true;
            if (!apiResponse.IsSuccessStatusCode)
                isSuccess = false;

            //Update status
            await PatchTransactionStatusAsync(
                RequestStage.VOLPAY,
                isSuccess ? RequestStatus.INITIATED : RequestStatus.FAILED,
                $"VolPay Response: {msg}",
                cosmosPaymentItem);

            if (isSuccess)
                await PatchTransactionVolPayAsync(response, cosmosPaymentItem);

            // Send message to service bus
            object addInfo = isSuccess 
                                ? new { message = JObject.Parse(msg) } 
                                : new { volPayResponse = $"Unsuccesful response from VolPay.  StatusCode: {apiResponse.StatusCode} Message :" + msg };
            cosmosPaymentItem.Status = isSuccess ? RequestStatus.INITIATED.ToString() : RequestStatus.FAILED.ToString();
            var serviceBusMessage = ServiceBusHelper.CreateServiceBusMessage(cosmosPaymentItem, isSuccess, addInfo, null);

            await _serviceBusMessageService.SendMessageToServiceBusAsync(
                serviceBusMessage,
                isSuccess ? PaymentRequestConstants.SuccessServiceBusSubject : PaymentRequestConstants.FailureServiceBusSubject);

            return true;
        }
        catch (Exception ex)
        {
            cosmosPaymentItem = await PatchTransactionStatusAsync(RequestStage.VOLPAY, RequestStatus.FAILED, $"Error: {ex.Message}", cosmosPaymentItem);
            var addInfo = new
            {
                cosmosPaymentItem.PaymentReference,
                Status = PaymentRequestConstants.TransactionFailed,
                Message = $"VolPay Exception: {ex.Message}"
            };
            var serviceBusMessage = ServiceBusHelper.CreateServiceBusMessage(cosmosPaymentItem, false, addInfo, null);
            await _serviceBusMessageService.SendMessageToServiceBusAsync(serviceBusMessage, PaymentRequestConstants.FailureServiceBusSubject);
            throw new VolPayProcessingException(ex.Message);
        }
    }

    public async Task<HttpResponseMessage> SendTransactionAsync(VolPayRequest volPayRequest)
    {
        _logger.LogInformation($"Request sent to VolPay: {JsonConvert.SerializeObject(volPayRequest)}");
        CancellationToken ct = CancellationToken.None;
        var tokenResponse = await GetVolanteTokenAsync(ct);
        var tokenString = await tokenResponse.Content.ReadAsStringAsync();
        _logger.LogInformation($"Response from token endpoint: {tokenString}");

        if (!string.IsNullOrWhiteSpace(tokenString))
        {
            var tokenStringDes = JsonConvert.DeserializeObject<VolPayTokenResponse>(tokenString);
            var token = tokenStringDes.SsnTkn;

            var headers = new List<HeaderEntry>()
            {
                    new HeaderEntry("tenantid", "MASTER"),
                    new HeaderEntry("External-Auth", "false"),
                    new HeaderEntry("AuthorizationWithoutValidation", $"Bearer:{token}")
            };
            _logger.LogInformation($"VolPay Send Transaction Url: {BaseAddress}");

            var response = await base.PostAsync(_appSettings.VOLPAY_SEND_PATH, volPayRequest, ct, headers.ToArray());
            _logger.LogInformation($"Raw response from VolPay: {JsonConvert.SerializeObject(response)}");
            return response;
        }
        else
        {
            return new HttpResponseMessage() { StatusCode = HttpStatusCode.InternalServerError, Content = new StringContent("Unable to get token") };
        }
    }

    public async Task<HttpResponseMessage> GetVolanteTokenAsync(CancellationToken ct)
    {
        var headers = new List<HeaderEntry>()
        {
            new HeaderEntry("tenantid", "MASTER")
        };

        _logger.LogInformation($"VolPay Token Url: {BaseAddress}{_appSettings.VOLPAY_TOKEN_PATH}");
        var req = new { UsrId = _appSettings.VOLPAY_TOKEN_USER, Pswd = _appSettings.VOLPAY_TOKEN_PASSWORD };
        return await base.PostAsync(_appSettings.VOLPAY_TOKEN_PATH, req, ct, headers.ToArray());
    }

    private async Task<EvolvePaymentRequest> PatchTransactionStatusAsync(RequestStage stage, RequestStatus status, string additionalInfo, EvolvePaymentRequest request)
    {
        // Patch cosmos item
        var patchOperationStatus = EvolvePaymentRequestHelper.GetStatusPatchOperation(stage, status, additionalInfo);
        return await _cosmosdB.PatchItemAsync(request, patchOperationStatus);
    }

    private async Task<EvolvePaymentRequest> PatchTransactionVolPayAsync(VolPayResponse response, EvolvePaymentRequest request)
    {
        var patchOperationVolPay = EvolvePaymentRequestHelper.GetVolPayResponsePatchOperation(response);
        return await _cosmosdB.PatchItemAsync(request, patchOperationVolPay);
    }
}