﻿using System;
using System.Net.Http;
using Newtonsoft.Json;
using System.Threading;
using System.Threading.Tasks;
using Evolve.Digital.Core.Api;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SendPaymentServicesFA.Helpers;
using SendPaymentServicesFA.Settings;
using SendPaymentServicesFA.Interface;
using SendPaymentServicesFA.Constants;
using SendPaymentServicesFA.Exceptions;
using SendPaymentServicesFA.Models.Response;
using Evolve.Digital.Shared.Models.Payments;
using SendPaymentServicesFA.Models.Business;
using SendPaymentServicesFA.Interface.Adapters;
using SendPaymentServicesFA.Interface.Services;

namespace SendPaymentServicesFA.Services.Facade.SubSystems;

public class PrefundLedgerSystem : ApiAdapterBase, IPrefundLedgerService
{
    protected override string BaseAddress { get { return _appSettings.PREFUND_LEDGER_BASE_URL; } }

    private readonly IPaymentCosmosDBAdapter _cosmosdB;
    private readonly IEvolvePaymentRequestHelper _evolvePaymentRequestHelper;
    private readonly IServiceBusMessageService _serviceBusMessageService;
    private readonly AppSettings _appSettings;
    private readonly ILogger<PrefundLedgerSystem> _logger;

    public PrefundLedgerSystem(
        IHttpClientFactory clientFactory,
        IPaymentCosmosDBAdapter cosmosdB,
        IEvolvePaymentRequestHelper evolvePaymentRequestHelper,
        IServiceBusMessageService serviceBusMessageService,
        IOptions<AppSettings> appSettings,
        ILogger<PrefundLedgerSystem> logger) : base(clientFactory)
    {
        _cosmosdB = cosmosdB;
        _evolvePaymentRequestHelper = evolvePaymentRequestHelper;
        _serviceBusMessageService = serviceBusMessageService;
        _appSettings = appSettings.Value;
        _logger = logger;
    }

    public async Task<EvolvePaymentRequest> PerformFraudCheck(EvolvePaymentRequest request)
    {
        try
        {
            _logger.LogInformation("Peforming fraud check");
            var businessPaymentRequest = _evolvePaymentRequestHelper.ConvertToBusinessDocument(request);
            _logger.LogInformation($"Json request sent to prefund ledger for fraud/sanctions check {JsonConvert.SerializeObject(businessPaymentRequest)}");


            var prefundResponse = await SendFraudSanctionsCheck(businessPaymentRequest);
            _logger.LogInformation($"Raw Response from prefund ledger: {JsonConvert.SerializeObject(prefundResponse)}");
            var msg = await prefundResponse?.Content?.ReadAsStringAsync();
            _logger.LogInformation($"Message content from prefund ledger response: {msg}");

            var response = JsonConvert.DeserializeObject<PrefundLedgerResponse>(msg);

            #region FAILURE
            // Response received but status code does not indicate success
            if (Convert.ToInt16(prefundResponse.StatusCode) != StatusCodes.Status200OK)
            {
                _logger.LogError("StatusCode and Message from Prefund Ledger - Unsuccessful response  ({0}): {1}", prefundResponse.StatusCode, msg);

                var errorResponse = JsonConvert.DeserializeObject<PrefundErrorResponse>(msg);
                
                if (errorResponse.Code == 0 && response.StatusCode == null)
                {
                    _logger.LogInformation($"Response from Prefund Ledger: StatusCode: {prefundResponse.StatusCode} Message: {msg}");
                }
                else if (errorResponse.Data.ToString().Contains(PrefundLedgerConstants.INSUFFICIENT_FUNDS_ERROR_MESSAGE))
                {
                    throw new PrefundLedgerException(PrefundLedgerConstants.INSUFFICIENT_FUNDS);
                }
                else if (errorResponse.Data.ToString().Contains(PrefundLedgerConstants.CYCLIC_DEPENDENCY_DETECTED))
                {
                    throw new PrefundLedgerException($"{PrefundLedgerConstants.CYCLIC_DEPENDENCY_DETECTED}: Fraud/Sanctions Check failed.");
                }
                else if (errorResponse.Code == 400)
                {
                    throw new PrefundLedgerException($"Fraud/Sanctions Check failed. {errorResponse?.Type} {errorResponse?.Data}");
                }
                else
                {
                    _logger.LogWarning($"Unhandled case from Prefund Ledger.  Response is {JsonConvert.SerializeObject(msg)}");
                    throw new PrefundLedgerException($"Fraud/Sanctions Check failed. {errorResponse.Type} {errorResponse.Data}");
                }
            }
            #endregion

            #region SUCCESS

            // Update Cosmos Document
            await PatchTransactionStatus(RequestStage.FRAUDSANCTIONCHECK, RequestStatus.ACCEPTED, "Prefund Ledger completed", request);

            var patchOperation_GluId = EvolvePaymentRequestHelper.GetGluIdUpdatePatchOperation(response.GluId, response.GluId_s, response.GluId_d);
            request = await _cosmosdB.PatchItemAsync(request, patchOperation_GluId);

            #endregion

            return request;
        }
        catch (Exception ex)
        {
            var document = await PatchTransactionStatus(RequestStage.FRAUDSANCTIONCHECK, RequestStatus.FAILED, $"Error: {ex.Message}", request);

            var serviceBusMessage = ServiceBusHelper.CreateServiceBusMessage(document, false,
                    new { message = ex.Message }, null);
            await _serviceBusMessageService.SendMessageToServiceBusAsync(serviceBusMessage, PaymentRequestConstants.FailureServiceBusSubject);

            throw new PrefundLedgerException(ex.Message, ex.InnerException);
        }
    }

    public async Task<HttpResponseMessage> SendFraudSanctionsCheck(BusinessEvolvePaymentRequest businessEvolvePaymentRequest) =>
         await base.PostAsync(string.Format(_appSettings.PREFUND_LEDGER_SEND_PATH), businessEvolvePaymentRequest, CancellationToken.None);


    public async Task<HttpResponseMessage> SendPaymentStatus(BusinessEvolvePaymentRequest businessEvolvePaymentRequest)
    {
        try
        {
            CancellationToken ct = CancellationToken.None;
            _logger.LogInformation($"Calling Prefund ledger Status endpoint");
            _logger.LogInformation($"Request sent to Prefund Ledger status endpoint: {JsonConvert.SerializeObject(businessEvolvePaymentRequest)}");
            return await base.PostAsync(string.Format(_appSettings.PREFUND_LEDGER_STATUS_PATH), businessEvolvePaymentRequest, ct);
        }
        catch (ServiceException ex)
        {
            // ServiceException contains the status code, response headers, and response body
            _logger.LogError("Error calling the API: status code {statusCode} and error message {errorMessage}.", ex.StatusCode, ex.ResponseMessage);

            // Return null
            return null;
        }
    }

    private async Task<EvolvePaymentRequest> PatchTransactionStatus(RequestStage stage, RequestStatus status, string additionalInfo, EvolvePaymentRequest request)
    {
        // Patch cosmos item
        var patchOperationStatus = EvolvePaymentRequestHelper.GetStatusPatchOperation(stage, status, additionalInfo);

        return await _cosmosdB.PatchItemAsync(request, patchOperationStatus);
    }
}