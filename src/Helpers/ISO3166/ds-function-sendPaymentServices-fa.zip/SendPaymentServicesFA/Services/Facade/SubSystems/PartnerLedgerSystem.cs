﻿using System;
using Dapper;
using System.Linq;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SendPaymentServicesFA.Helpers;
using SendPaymentServicesFA.Settings;
using SendPaymentServicesFA.Constants;
using SendPaymentServicesFA.Exceptions;
using Evolve.Digital.Shared.Models.Payments;
using SendPaymentServicesFA.Models.Response;
using SendPaymentServicesFA.Interface.Adapters;
using SendPaymentServicesFA.Interface.Repository;
using SendPaymentServicesFA.Interface.Services;

namespace SendPaymentServicesFA.Services.Facade.SubSystems;

public class PartnerLedgerSystem : IPartnerLedgerRepository
{
    private readonly IPaymentCosmosDBAdapter _cosmosdB;
    private readonly IPartnerLedgerCosmosDBAdapter _db;
    private readonly IServiceBusMessageService _serviceBusMessageService;
    private readonly AppSettings _appSettings;
    private readonly ILogger<PartnerLedgerSystem> _logger;

    public PartnerLedgerSystem(
        IPaymentCosmosDBAdapter cosmosdB, 
        IPartnerLedgerCosmosDBAdapter db,
         IServiceBusMessageService serviceBusMessageService,
        IOptions<AppSettings> appSettings, 
        ILogger<PartnerLedgerSystem> logger)
    {
        _cosmosdB = cosmosdB;
        _db = db;
        _serviceBusMessageService = serviceBusMessageService;
        _appSettings = appSettings.Value;
        _logger = logger;
    }

    public async Task<EvolvePaymentRequest> PerformAccountLookupUpdate(EvolvePaymentRequest request)
    {
        // Partner Ledger Lookup
        var accountNumber = request.SourceAccount.AccountNumber;
        PartnerLedgerResponse partnerLedgerResponse;

        try
        {
            // Retrieve from cosmos
            partnerLedgerResponse = await _db.GetItemAsync(accountNumber);

            // Try retrieving from SQL
            if (partnerLedgerResponse.ErrorMessage != null)
            {
                _logger.LogInformation($"Error message while retrieving partner ledger information from cosmos: {partnerLedgerResponse.ErrorMessage}");
                _logger.LogInformation($"Retrieving partner ledger information from SQL DB");
                partnerLedgerResponse = await PartnerLedgerVAccountLookup(accountNumber);
                if (partnerLedgerResponse.ErrorMessage == null)
                {
                    _logger.LogInformation($"Retrieval from SQL successful.  Adding this entry to cosmos db {JsonConvert.SerializeObject(partnerLedgerResponse)}");
                    // Update fboAccounts container with this entry
                    var response = await _db.CreateItemAsync(partnerLedgerResponse);
                }
            }
        }
        catch (CosmosGetException ex)
        {
            _logger.LogError($"An exception occured while calling Cosmos Partner Ledger collection: Message, StackTrace {ex.Message} {ex.StackTrace}");
            _logger.LogInformation($"Retrieving partner ledger information from SQL DB");
            partnerLedgerResponse = await PartnerLedgerVAccountLookup(accountNumber);
        }
        catch (Exception ex)
        {
            _logger.LogError($"An exception occured while calling stored procedure for partner ledger lookup: Message, StackTrace {ex.Message} {ex.StackTrace}");
            _logger.LogWarning($"Partner Ledger Lookup was unsuccessful. Error Message : {ex.Message}");
            var document = await PatchTransactionStatus(RequestStage.ACCOUNTLOOKUP, RequestStatus.FAILED, ex.Message, request);

            var serviceBusMessage = ServiceBusHelper.CreateServiceBusMessage(document, false,
                    new { message = ex.Message }, null);
            await _serviceBusMessageService.SendMessageToServiceBusAsync(serviceBusMessage, PaymentRequestConstants.FailureServiceBusSubject);

            throw new PartnerLedgerException(ex.Message);
        }
        if (partnerLedgerResponse.ErrorMessage != null)
        {
            _logger.LogWarning($"Partner Ledger Lookup was unsuccessful. Error Message : {partnerLedgerResponse.ErrorMessage}");
            var document = await PatchTransactionStatus(RequestStage.ACCOUNTLOOKUP, RequestStatus.FAILED, partnerLedgerResponse.ErrorMessage, request);

            var serviceBusMessage = ServiceBusHelper.CreateServiceBusMessage(document, false,
                    new { message = partnerLedgerResponse.ErrorMessage }, null);
            await _serviceBusMessageService.SendMessageToServiceBusAsync(serviceBusMessage, PaymentRequestConstants.FailureServiceBusSubject);

            throw new PartnerLedgerException(partnerLedgerResponse.ErrorMessage);
        }

        // Check if account is not active - either closed or blocked
        if (partnerLedgerResponse.AccountStatus == "CLOSED" || partnerLedgerResponse.AccountStatus == "BLOCKED")
        {
            // Partner Ledger Update
            var document = await PatchTransactionStatus(RequestStage.ACCOUNTLOOKUP, RequestStatus.REJECTED, $"Debtor Account Status: {partnerLedgerResponse.AccountStatus}", request);

            var serviceBusMessage = ServiceBusHelper.CreateServiceBusMessage(document, false,
                    new { message = $"Account Status for account {accountNumber}: {partnerLedgerResponse.AccountStatus}" }, null);
            await _serviceBusMessageService.SendMessageToServiceBusAsync(serviceBusMessage, PaymentRequestConstants.FailureServiceBusSubject);

            throw new PartnerLedgerException(partnerLedgerResponse.AccountStatus);
        }

        _logger.LogInformation($"Partner ledger lookup successful. Response {JsonConvert.SerializeObject(partnerLedgerResponse)}");

        // Partner Ledger Update
        await PatchTransactionStatus(RequestStage.ACCOUNTLOOKUP, RequestStatus.COMPLETED, "PartnerLedgerLookup completed", request);

        var partnerLedgerUpdate = EvolvePaymentRequestHelper.SetAccountLookupPatchoperation(partnerLedgerResponse);
        return await _cosmosdB.PatchItemAsync(request, partnerLedgerUpdate);
    }

    public async Task<PartnerLedgerResponse> PartnerLedgerVAccountLookup(string vAccount)
    {
        _logger.LogInformation($"Executing SP {_appSettings.PARTNER_LEDGER_SPNAME} with vAccount {vAccount}");
        using SqlConnection sqlConnection = new SqlConnection(_appSettings.PARTNER_LEDGER_SQL_CONNSTRING);
        string sql = $"exec {_appSettings.PARTNER_LEDGER_SPNAME} @vAccount";
        var parameters = new { vAccount = vAccount };
        var partnerLedgerResponse = (await sqlConnection.QueryAsync<PartnerLedgerResponse>(sql, parameters)).FirstOrDefault();
        _logger.LogInformation($"Response from Partner Ledger Stored procedure {JsonConvert.SerializeObject(partnerLedgerResponse)}");
        return partnerLedgerResponse;
    }

    private async Task<EvolvePaymentRequest> PatchTransactionStatus(RequestStage stage, RequestStatus status, string additionalInfo, EvolvePaymentRequest request)
    {
        // Patch cosmos item
        var patchOperationStatus = EvolvePaymentRequestHelper.GetStatusPatchOperation(stage, status, additionalInfo);

        return await _cosmosdB.PatchItemAsync(request, patchOperationStatus);
    }
}