﻿using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Evolve.Digital.Shared.Models.Payments;
using SendPaymentServicesFA.Services.Facade.SubSystems;

namespace SendPaymentServicesFA.Services.Facade;

public class PreRtpChecksFacade : IPreRtpChecksFacade
{
    private readonly PartnerLedgerSystem _partnerLedgerSystem;
    private readonly PrefundLedgerSystem _prefundLedgerSystem;
    private readonly ILogger<PreRtpChecksFacade> _logger;

    public PreRtpChecksFacade(PartnerLedgerSystem partnerLedgerSystem, PrefundLedgerSystem prefundLedgerSystem, ILogger<PreRtpChecksFacade> logger)
    {
        _partnerLedgerSystem = partnerLedgerSystem;
        _prefundLedgerSystem = prefundLedgerSystem;
        _logger = logger;
    }

    public async Task<EvolvePaymentRequest> PerformPreRtpChecks(EvolvePaymentRequest request)
    {
        _logger.LogInformation("Performing operations using the facade.");

        // Call Partner ledger
        request = await _partnerLedgerSystem.PerformAccountLookupUpdate(request);

        // Call Prefund ledger
        request = await _prefundLedgerSystem.PerformFraudCheck(request);
        return request;
    }
}

public interface IPreRtpChecksFacade
{
    Task<EvolvePaymentRequest> PerformPreRtpChecks(EvolvePaymentRequest request);
}