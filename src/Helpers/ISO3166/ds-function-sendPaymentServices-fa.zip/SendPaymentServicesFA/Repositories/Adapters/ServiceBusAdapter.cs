﻿using System;
using System.Threading.Tasks;
using Azure.Messaging.ServiceBus;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SendPaymentServicesFA.Models;
using SendPaymentServicesFA.Settings;
using System.Diagnostics.CodeAnalysis;
using SendPaymentServicesFA.Interface.Adapters;

namespace SendPaymentServicesFA.Repositories.Adapters;

[ExcludeFromCodeCoverage]
public class ServiceBusAdapter : IServiceBusAdapter, IAsyncDisposable
{
    private readonly AppSettings _appSettings;
    private readonly ILogger<ServiceBusAdapter> _logger;

    private ServiceBusClient _serviceBusClient;
    private ServiceBusSender _queueserviceBusSender;

    public ServiceBusAdapter(IOptions<AppSettings> appSettings, ILogger<ServiceBusAdapter> logger)
    {
        _appSettings = appSettings.Value;
        _logger = logger;
    }
    public async Task SendMessage(ServiceBusRequest serviceBusRequest)
    {
        try
        {
            var message = new ServiceBusMessage(serviceBusRequest.Content)
            {
                Subject = serviceBusRequest.Subject
            };
            await SendMessageToServiceBusQueue(message, serviceBusRequest.QueueName);

        }
        catch (ServiceBusException e)
        {

            _logger.LogError(
                "Error while sending message to service bus.  Content: {Content}. Queue: {Queue}.  Error: {Message}.  Reason: {Reason}",
                serviceBusRequest.Content,
                serviceBusRequest.QueueName,
                e.Message,
                e.Reason
                );
            throw;
        }
    }

    protected virtual async Task SendMessageToServiceBusQueue(ServiceBusMessage message, string queueName)
    {
        await (await GetServiceBusSender(queueName)).SendMessageAsync(message);
    }

    private async Task<ServiceBusSender> GetServiceBusSender(string queueName)
    {
        if (_queueserviceBusSender is null || _queueserviceBusSender.IsClosed)
        {
            _queueserviceBusSender = (await GetServiceBusClient()).CreateSender(queueName);
        }

        return _queueserviceBusSender;
    }

    protected virtual async Task<ServiceBusClient> GetServiceBusClient()
    {
        if (_serviceBusClient is null)
        {
            _serviceBusClient = new ServiceBusClient(_appSettings.SERVICE_BUS_CONNSTRING);
        }
        else if (_serviceBusClient.IsClosed)
        {
            try
            {
                await _serviceBusClient.DisposeAsync();
            }
            catch (Exception)
            {

                // Protect ourselves in case the client above throws an exception during dispose
            }

            _serviceBusClient = new ServiceBusClient(_appSettings.SERVICE_BUS_CONNSTRING);
        }
        return _serviceBusClient;
    }

    /// <summary>
    /// <inheritdoc/>
    /// </summary>
    /// <returns></returns>
    public async ValueTask DisposeAsync()
    {
        await _queueserviceBusSender.DisposeAsync();
        await _serviceBusClient.DisposeAsync();
        GC.SuppressFinalize(this);
    }
}