﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Azure.Cosmos;
using Evolve.Digital.Core.CosmosDB;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SendPaymentServicesFA.Settings;
using SendPaymentServicesFA.Exceptions;
using SendPaymentServicesFA.Models.Request;
using SendPaymentServicesFA.Models.Response;
using SendPaymentServicesFA.Interface.Adapters;

namespace SendPaymentServicesFA.Repositories;

public class PartnerLedgerCosmosDBAdapter : CosmosDBDataAdapter, IPartnerLedgerCosmosDBAdapter
{
    private readonly AppSettings _appSettings;
    private readonly ILogger<PartnerLedgerCosmosDBAdapter> _logger;

    public PartnerLedgerCosmosDBAdapter(IOptions<AppSettings> appSettings, ILogger<PartnerLedgerCosmosDBAdapter> logger)
    {
        _appSettings = appSettings.Value;
        _logger = logger;
    }

    protected override string ConnectionString { get { return _appSettings.COSMOS_PAYMENT_CONNSTRING; } }

    protected override string DatabaseId { get { return _appSettings.COSMOS_PAYMENT_DATABASE; } }

    protected override string ContainerId { get { return _appSettings.COSMOS_PARTNER_LEDGER_CONTAINER; } }

    protected override string ApplicationName { get { return "SendPaymentServices"; } }

    public async Task<PartnerLedgerResponse> GetItemAsync(string accountNumber)
    {
        try
        {
            var queryDefinition = new QueryDefinition("Select * from c WHERE c.vAccountNumber = @accountNumber")
       .WithParameter("@accountNumber", accountNumber);

            var response = (await base.FindAllItemsAsync<PartnerLedgerResponse>(queryDefinition)).FirstOrDefault();

            if (response == null)
            {
                return new PartnerLedgerResponse()
                {
                    ErrorMessage = "Invalid V Account "
                };
            }
            return response;
        }
        catch (Exception ex)
        {
            throw new CosmosGetException(ex.Message);
        }
    }

    public async Task<PartnerLedgerRequest> CreateItemAsync(PartnerLedgerResponse partnerLedgerResponse)
    {
        var partnerLedgerRequest = new PartnerLedgerRequest()
        {
            Id = Guid.NewGuid().ToString(),
            CifNo = partnerLedgerResponse.CifNo,
            FboAccount = partnerLedgerResponse.FboAccount,
            FboAccountName = partnerLedgerResponse.FboAccountName,
            TaxId = partnerLedgerResponse.TaxId,
            UserIsBusiness = partnerLedgerResponse.UserIsBusiness,
            VAccountNumber = partnerLedgerResponse.VAccountNumber,
            AccountStatus = partnerLedgerResponse.AccountStatus
        };
        try
        {
            ItemResponse<PartnerLedgerRequest> response = await base.CreateItemAsync(partnerLedgerRequest);

            return response.Resource;
        }
        catch (CosmosException ce)
        {
            if (ce.StatusCode == System.Net.HttpStatusCode.Conflict)
            {
                return null;
            }
            throw;
        }
    }
}