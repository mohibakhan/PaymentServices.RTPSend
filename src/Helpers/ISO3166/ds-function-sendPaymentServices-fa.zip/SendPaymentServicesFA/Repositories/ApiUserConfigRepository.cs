﻿using System;
using Dapper;
using System.Linq;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SendPaymentServicesFA.Settings;
using SendPaymentServicesFA.Models.Response;
using SendPaymentServicesFA.Interface.Repository;

namespace SendPaymentServicesFA.Repositories;

public class ApiUserConfigRepository : IApiUserConfigRepository
{
    private readonly AppSettings _appSettings;
    private readonly ILogger<ApiUserConfigRepository> _logger;

    public ApiUserConfigRepository(IOptions<AppSettings> appSettings, ILogger<ApiUserConfigRepository> logger)
    {
        _appSettings = appSettings.Value;
        _logger = logger; 
    }

    /// <summary>
    /// Returns API User configuration
    /// </summary>
    /// <param name="ClientId"></param>
    /// <param name="MerchantId"></param>
    /// <param name="log"></param>
    /// <returns><see cref="ApiUserConfigResponse"/></returns>
    public async Task<ApiUserConfigResponse> GetApiUserConfigAsync(string clientId, string merchantId)
    {
        try
        {
            using SqlConnection sqlConnection = new SqlConnection(_appSettings.PMT_SVC_SQL_CONNECTION_STRING);
            string sql = "exec [dbo].[spGetAPIUserConfig] @ClientId, @MerchantId";
            var parameters = new { ClientId = clientId, MerchantId = merchantId };
            var apiUserConfigResponse = (await sqlConnection.QueryAsync<ApiUserConfigResponse>(sql, parameters)).FirstOrDefault();
            _logger.LogInformation($"API User Config completed. Response {JsonConvert.SerializeObject(apiUserConfigResponse)}");
            return apiUserConfigResponse;
        }
        catch (Exception ex)
        {
            _logger.LogCritical($"Error occured while calling API User config.  Message::{ex.Message} || StackTrace::{ex.StackTrace}");
            return null;
        }
    }
}