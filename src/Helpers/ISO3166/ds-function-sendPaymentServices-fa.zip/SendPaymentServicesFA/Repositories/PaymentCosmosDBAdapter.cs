﻿using Microsoft.Azure.Cosmos;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using Evolve.Digital.Core.CosmosDB;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SendPaymentServicesFA.Settings;
using System.Diagnostics.CodeAnalysis;
using Evolve.Digital.Shared.Models.Payments;
using SendPaymentServicesFA.Interface.Adapters;

namespace SendPaymentServicesFA.Repositories;

[ExcludeFromCodeCoverage]
public class PaymentCosmosDBAdapter : CosmosDBDataAdapter, IPaymentCosmosDBAdapter
{
    private readonly AppSettings _appSettings;
    private readonly ILogger<PaymentCosmosDBAdapter> _logger;

    public PaymentCosmosDBAdapter(IOptions<AppSettings> appSettings, ILogger<PaymentCosmosDBAdapter> logger)
    {
        _appSettings = appSettings.Value;
        _logger = logger;
    }

    protected override string ConnectionString { get { return _appSettings.COSMOS_PAYMENT_CONNSTRING; } }

    protected override string DatabaseId { get { return _appSettings.COSMOS_PAYMENT_DATABASE; } }

    protected override string ContainerId { get { return _appSettings.COSMOS_PAYMENT_CONTAINER; } }

    protected override string ApplicationName { get { return "SendPaymentServices"; } }

    /// <summary>
    /// Gets a cosmos document by id and evolvePaymentId field
    /// </summary>
    /// <param name="id"></param>
    /// <param name="evolvePaymentId"></param>
    /// <returns></returns>
    public async Task<EvolvePaymentRequest> GetItemAsync(string id, string evolvePaymentId)
    {
        try
        {
            var response = await base.GetItemAsync<EvolvePaymentRequest>(id, evolvePaymentId);

            return response.Resource;
        }
        catch (CosmosException ce)
        {
            _logger.LogError("Error while calling Cosmos Service: status code {statusCode} and error message {errorMessage}.", ce.StatusCode, ce.Message);
            return null;
        }
    }

    /// <summary>
    /// Creates a new PaymentRequest cosmos DB document
    /// </summary>
    /// <param name="evolvePaymentRequest"></param>
    /// <returns></returns>
    public async Task<EvolvePaymentRequest> CreateItemAsync(EvolvePaymentRequest evolvePaymentRequest)
    {
        try
        {
            ItemResponse<EvolvePaymentRequest> response = await base.CreateItemAsync(evolvePaymentRequest);

            return response.Resource;
        }
        catch (CosmosException ce)
        {
            if (ce.StatusCode == System.Net.HttpStatusCode.Conflict)
            {
                return null;
            }
            throw;
        }
    }

    public async Task<EvolvePaymentRequest> UpdateItemAsync(EvolvePaymentRequest evolvePaymentRequest)
    {
        try
        {
            ItemResponse<EvolvePaymentRequest> response = await base.UpsertItemAsync(evolvePaymentRequest);

            return response.Resource;
        }
        catch (CosmosException ce)
        {
            if (ce.StatusCode == System.Net.HttpStatusCode.Conflict)
            {
                return null;
            }
            throw;
        }
    }

    public async Task<EvolvePaymentRequest> PatchItemAsync(EvolvePaymentRequest evolvePaymentRequest, List<PatchOperation> patchOperations)
    {
        try
        {
            var response = await base.PatchItemAsync<EvolvePaymentRequest>(evolvePaymentRequest.Id, patchOperations, evolvePaymentRequest.EvolveId);

            return response.Resource;
        }
        catch (CosmosException ce)
        {
            if (ce.StatusCode == System.Net.HttpStatusCode.Conflict)
            {
                return null;
            }
            throw;
        }
    }

    public async Task<List<EvolvePaymentRequest>> FindAllItemsAsync(string evolveId)
    {
        var queryDefinition = new QueryDefinition("Select * from c WHERE c.evolveId = @evolveId")
           .WithParameter("@evolveId", evolveId);

        // If no items are found, an empty set is returned
        // This returns all the results from the query with no further iterations needed
        return await base.FindAllItemsAsync<EvolvePaymentRequest>(queryDefinition);
    }

    public async Task<List<EvolvePaymentRequest>> FindAllItemsAsync(string evolveId, string documentType, string documentSubType)
    {
        var queryDefinition = new QueryDefinition("Select * from c WHERE c.evolveId = @evolveId AND c.documentType = @documentType AND c.documentSubType = @documentSubType ")
           .WithParameter("@evolveId", evolveId)
           .WithParameter("@documentType", documentType)
           .WithParameter("@documentSubType", documentSubType);

        // If no items are found, an empty set is returned
        // This returns all the results from the query with no further iterations needed
        return await base.FindAllItemsAsync<EvolvePaymentRequest>(queryDefinition);
    }

    public async Task<List<EvolvePaymentRequest>> FindAllItemsByAmountAsync(string amount)
    {
        var queryDefinition = new QueryDefinition("Select * from c WHERE c.amount = @amount")
          .WithParameter("@amount", amount);

        // If no items are found, an empty set is returned
        // This returns all the results from the query with no further iterations needed
        return await base.FindAllItemsAsync<EvolvePaymentRequest>(queryDefinition);
    }

    public async Task<List<EvolvePaymentRequest>> FindAllItemsByaymentReferenceAsync(string paymentReference)
    {
        var queryDefinition = new QueryDefinition("Select * from c WHERE c.paymentReference  = @paymentReference")
          .WithParameter("@paymentReference", paymentReference);

        // If no items are found, an empty set is returned
        // This returns all the results from the query with no further iterations needed
        return await base.FindAllItemsAsync<EvolvePaymentRequest>(queryDefinition);
    }

    public async Task<bool> FindIfItemDuplicateAsync(string paymentReference, IHeaderDictionary headers)
    {
        var clientId = headers["x-client-id"].ToString();
        var merchantId = headers["x-merchant-id"].ToString();

        var queryDefinition = new QueryDefinition("Select * from c WHERE c.paymentReference  = @paymentReference AND c.clientId = @clientId AND c.merchantId = @merchantId")
          .WithParameter("@paymentReference", paymentReference)
          .WithParameter("@clientId", clientId)
          .WithParameter("@merchantId", merchantId);

        var response = await base.FindAllItemsAsync<EvolvePaymentRequest>(queryDefinition);

        if (response.Count == 0)
            return false;
        return true;
    }

    public async Task<List<EvolvePaymentRequest>> GetPayment(string evolveId, IHeaderDictionary headers)
    {
        var clientId = headers["x-client-id"].ToString();
        var merchantId = headers["x-merchant-id"].ToString();

        var queryDefinition = new QueryDefinition("Select * from c WHERE c.evolveId  = @evolveId AND c.clientId = @clientId AND c.merchantId = @merchantId")
          .WithParameter("@evolveId", evolveId)
          .WithParameter("@clientId", clientId)
          .WithParameter("@merchantId", merchantId);

        return await base.FindAllItemsAsync<EvolvePaymentRequest>(queryDefinition);
    }

    public async Task<List<EvolvePaymentRequest>> GetPaymentByReference(string paymentReference, IHeaderDictionary headers)
    {
        var clientId = headers["x-client-id"].ToString();
        var merchantId = headers["x-merchant-id"].ToString();

        var queryDefinition = new QueryDefinition("Select * from c WHERE c.paymentReference  = @paymentReference AND c.clientId = @clientId AND c.merchantId = @merchantId")
          .WithParameter("@paymentReference", paymentReference)
          .WithParameter("@clientId", clientId)
          .WithParameter("@merchantId", merchantId);

        return await base.FindAllItemsAsync<EvolvePaymentRequest>(queryDefinition);
    }
}