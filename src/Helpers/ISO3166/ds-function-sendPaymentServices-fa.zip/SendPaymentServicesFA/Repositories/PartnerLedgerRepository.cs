﻿using Dapper;
using System.Linq;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SendPaymentServicesFA.Settings;
using SendPaymentServicesFA.Models.Response;
using SendPaymentServicesFA.Interface.Repository;

namespace SendPaymentServicesFA.Repositories;

public class PartnerLedgerRepository : IPartnerLedgerRepository
{
    private readonly AppSettings _appSettings;
    private readonly ILogger<PartnerLedgerRepository> _logger;

    public PartnerLedgerRepository(IOptions<AppSettings> appSettings, ILogger<PartnerLedgerRepository> logger)
    {
        _appSettings = appSettings.Value;
        _logger = logger;
    }

    /// <summary>
    /// Returns API User configuration
    /// </summary>
    /// <param name="ClientId"></param>
    /// <param name="MerchantId"></param>
    /// <param name="log"></param>
    /// <returns><see cref="ApiUserConfigResponse"/></returns>
    public async Task<PartnerLedgerResponse> PartnerLedgerVAccountLookup(string vAccount)
    {
        using SqlConnection sqlConnection = new SqlConnection(_appSettings.PARTNER_LEDGER_SQL_CONNSTRING);
        string sql = $"exec {_appSettings.PARTNER_LEDGER_SPNAME} @vAccount";
        var parameters = new { vAccount = vAccount };
        var partnerLedgerResponse = (await sqlConnection.QueryAsync<PartnerLedgerResponse>(sql, parameters)).FirstOrDefault();
        _logger.LogInformation($"Response from Partner Ledger Stored procedure {JsonConvert.SerializeObject(partnerLedgerResponse)}");
        return partnerLedgerResponse;
    }
}