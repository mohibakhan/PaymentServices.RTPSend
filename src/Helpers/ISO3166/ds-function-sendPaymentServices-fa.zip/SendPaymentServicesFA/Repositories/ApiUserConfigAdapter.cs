﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Evolve.Digital.Core.CosmosDB;
using SendPaymentServicesFA.Settings;
using SendPaymentServicesFA.Exceptions;
using SendPaymentServicesFA.Models.Response;
using SendPaymentServicesFA.Interface.Adapters;

namespace SendPaymentServicesFA.Repositories;
public class ApiUserConfigAdapter : CosmosDBDataAdapter, IApiUserConfigCosmosAdapter
{
    private readonly AppSettings _appSettings;
    private readonly ILogger<ApiUserConfigAdapter> _logger;

    public ApiUserConfigAdapter(IOptions<AppSettings> appSettings, ILogger<ApiUserConfigAdapter> logger)
    {
        _appSettings = appSettings.Value;
        _logger = logger;
    }

    protected override string ConnectionString { get { return _appSettings.COSMOS_PAYMENT_CONNSTRING; } }

    protected override string DatabaseId { get { return _appSettings.COSMOS_PAYMENT_DATABASE; } }

    protected override string ContainerId { get { return _appSettings.COSMOS_API_CONFIG_CONTAINER; } }

    protected override string ApplicationName { get { return "SendPaymentServices"; } }

    public async Task<ApiUserConfigResponse> GetApiUserConfigAsync(string clientId, string merchantId, string subscriptionKey)
    {
        try
        {
            var queryDefinition = new QueryDefinition("Select * from c WHERE c.clientId  = @clientId AND c.merchantId = @merchantId AND c.subscriptionKey = @subscriptionKey")
                .WithParameter("@clientId", clientId)
                .WithParameter("@merchantId", merchantId)
                .WithParameter("@subscriptionKey", subscriptionKey);

            var response = (await base.FindAllItemsAsync<ApiUserConfigResponse>(queryDefinition)).FirstOrDefault();

            return response;
        }
        catch (Exception ex)
        {
            throw new CosmosGetException(ex.Message);
        }
    }

    public async Task<ApiUserConfigResponse> GetApiUserConfigAsync(string clientId, string merchantId)
    {
        try
        {
            var queryDefinition = new QueryDefinition("Select * from c WHERE c.clientId  = @clientId AND c.merchantId = @merchantId")
                .WithParameter("@clientId", clientId)
                .WithParameter("@merchantId", merchantId);

            var response = (await base.FindAllItemsAsync<ApiUserConfigResponse>(queryDefinition)).FirstOrDefault();

            return response;
        }
        catch (Exception ex)
        {
            throw new CosmosGetException(ex.Message);
        }
    }
}
