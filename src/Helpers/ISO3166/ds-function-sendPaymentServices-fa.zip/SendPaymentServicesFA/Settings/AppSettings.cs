﻿namespace SendPaymentServicesFA.Settings;

public class AppSettings
{
    public string PREFUND_LEDGER_BASE_URL { get; set; }
    public string PREFUND_LEDGER_SEND_PATH { get; set; }
    public string PREFUND_LEDGER_STATUS_PATH { get; set; }
    public string COSMOS_PAYMENT_CONNSTRING { get; set; }
    public string COSMOS_PAYMENT_DATABASE { get; set; }
    public string COSMOS_PAYMENT_CONTAINER { get; set; }
    public string COSMOS_PARTNER_LEDGER_CONTAINER { get; set; }
    public string TABAPAY_SEND_URL { get; set; }
    public string TABAPAY_SEND_APIKEY { get; set; }
    public string TABAPAY_SEND_CLIENT_ID { get; set; }
    public string TABAPAY_SEND_MERCHANT_ID { get; set; }
    public string SERVICE_BUS_CONNSTRING { get; set; }
    public string SERVICE_BUS_QUEUE_NAME { get; set; }
    public string PMT_SVC_SQL_CONNECTION_STRING { get; set; }
    public string PARTNER_LEDGER_SQL_CONNSTRING { get; set; }
    public string PARTNER_LEDGER_SPNAME { get; set; }
    public string VOLPAY_BASE_URL { get; set; }
    public string VOLPAY_SEND_PATH { get; set; }
    public string VOLPAY_TOKEN_PATH { get; set; }
    public string VOLPAY_TOKEN_USER { get; set; }
    public string VOLPAY_TOKEN_PASSWORD { get; set; }
    public string VOLPAY_TOKEN_URL { get; set; }
    public string RTP_SEND_TRAN_CODE { get; set; }
    public string SERVICE_BUS_TOPIC_NAME { get; set; }
    public string SERVICE_BUS_SUBSCRIPTION_NAME { get; set; }
    public string VALIDATE_PAYMENT_URL { get; set; }
    public string VALIDATE_PAYMENT_HOSTKEY_HEADER { get; set; }
    public string COSMOS_API_CONFIG_CONTAINER { get; set; }
}