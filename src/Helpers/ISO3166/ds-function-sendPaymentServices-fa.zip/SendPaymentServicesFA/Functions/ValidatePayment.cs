using System;
using System.Net;
using System.Linq;
using Newtonsoft.Json;
using Microsoft.Azure.Cosmos;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using SendPaymentServicesFA.Constants;
using SendPaymentServicesFA.Exceptions;
using Microsoft.Azure.Functions.Worker;
using Evolve.Digital.Core.Utilities.Http;
using SendPaymentServicesFA.Models.Request;
using Evolve.Digital.Shared.Models.Payments;
using SendPaymentServicesFA.Interface.Adapters;
using SendPaymentServicesFA.Interface.Repository;
using SendPaymentServicesFA.Interface.Services;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using ServiceErrorResponse = SendPaymentServicesFA.Models.ServiceErrorResponse;

namespace SendPaymentServicesFA.Functions;

public class ValidatePayment
{
    private readonly IPaymentCosmosDBAdapter _paymentCosmosDBService;
    private readonly IApiUserConfigRepository _apiUserConfigRepository;
    private readonly ILogger<ValidatePayment> log;
    private readonly IPrefundEventProcessor _prefundEventProcessor;

    /// <summary>
    /// Constructor method for CreatePayment
    /// </summary>
    /// <param name="httpContextAccessor"></param>
    /// <param name="telemetryClient"></param>
    public ValidatePayment(
        IPaymentCosmosDBAdapter paymentCosmosDBService,
        IApiUserConfigRepository apiUserConfigRepository,
        IPrefundEventProcessor prefundEventProcessor,
        ILogger<ValidatePayment> logger
        )
    {
        _paymentCosmosDBService = paymentCosmosDBService;
        _apiUserConfigRepository = apiUserConfigRepository;
        _prefundEventProcessor = prefundEventProcessor;
        log = logger;
    }

    /// <summary>
    /// The function app endpoint called by Evolve RTP Ledger
    /// with status of Payment Request
    /// </summary>
    /// <param name="req"></param>
    /// <param name="log"></param>
    /// <returns>Ok, Accepted, BadRequest, InternalServerError</returns>
    [Function("ValidatePayment")]
    [OpenApiOperation(operationId: "ValidatePayment", tags: ["ValidatePayment"])]
    [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(RtpValidateEvent), Description = "RtpValidateRequest", Required = true)]
    [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(string), Description = "The OK response")]
    [OpenApiResponseWithBody(statusCode: HttpStatusCode.NoContent, contentType: "application/json", bodyType: typeof(string), Description = "The No Content response")]
    [OpenApiResponseWithBody(statusCode: HttpStatusCode.BadRequest, contentType: "application/json", bodyType: typeof(ServiceErrorResponse), Description = "Bad Request")]
    [OpenApiResponseWithBody(statusCode: HttpStatusCode.InternalServerError, contentType: "application/json", bodyType: typeof(ServiceErrorResponse), Description = "Internal Server Error")]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req)
    {
        try
        {
            // Get request
            var request = await req.GetJsonBodyAsync<RtpValidateEvent>();

            log.LogInformation($"Request body: {JsonConvert.SerializeObject(request)}");

            var patchOperation_Status = new List<PatchOperation>();

            if (request == null)
                return await ActionResultResponseHelper.CreateBadRequestAsync(req.HttpContext,
                    new ServiceErrorResponse { Error = "Request cannot be null", Message = "Request cannot be null or empty." });

            if (!PrefundLedgerConstants.ValidEvents.Contains(request.Event) || request.Metadata?.EvolveId == null || request.Event == null)
            {
                log.LogWarning($"Event {request.Event} for payment with evolveId {request.Metadata?.EvolveId} is out of scope for Validate payment.");
                return await ActionResultResponseHelper.CreateNoContentAsync();
            }

            log.LogInformation($"Processing Event {request.Event} for evolveId: {request.Metadata.EvolveId}");

            // Get item from cosmos DB
            var cosmosPaymentItem = (await _paymentCosmosDBService.FindAllItemsAsync(request.Metadata.EvolveId)).FirstOrDefault();

            // Handle if cosmos document not found
            if (cosmosPaymentItem == null || cosmosPaymentItem.DocumentType != PaymentRequestConstants.DocumentType)
                return await ActionResultResponseHelper.CreateNoContentAsync();

            if (IsPaymentCompleted(cosmosPaymentItem.StatusHistory.Last().Status))
            {
                return await ActionResultResponseHelper.CreateConflictAsync(req.HttpContext,
                new ServiceErrorResponse { Error = "Request already processed", Message = $"Pleae check evolveId {request.Metadata.EvolveId} sent in this request." });
            }

            log.LogInformation($"Event processing for payment with " +
                $"evolveId: {cosmosPaymentItem.EvolveId}, Event: {request.Event}, PaymentHandler: {cosmosPaymentItem.DocumentSubType}");

            var eventHandlerResponse = await _prefundEventProcessor.ProcessEventAsync(request, cosmosPaymentItem);

            return await ActionResultResponseHelper.CreateOkAsync(req.HttpContext, eventHandlerResponse);
        }
        catch(EventHandlerException ex)
        {
            log.LogError(ex, "Validate Payment Services EventHandlerException: {Message}, {Stack}, {Inner_Exception}", ex.Message, ex.StackTrace, ex.InnerException);
            return await ActionResultResponseHelper.CreateInternalServerErrorAsync(req.HttpContext,
               new ServiceErrorResponse { Error = "An unexpected error occured", Message = "Please contact Evolve for additional details." });
        }
        catch(TabaPayProcessingException ex)
        {
            log.LogError(ex, "Validate Payment Services TabaPayProcessingException: {Message}, {Stack}, {Inner_Exception}", ex.Message, ex.StackTrace, ex.InnerException);
            return await ActionResultResponseHelper.CreateInternalServerErrorAsync(req.HttpContext,
               new ServiceErrorResponse { Error = "An unexpected error occured", Message = "Please contact Evolve for additional details." });
        }
        catch (VolPayProcessingException ex)
        {
            log.LogError(ex, "Validate Payment Services VolPayProcessingException: {Message}, {Stack}, {Inner_Exception}", ex.Message, ex.StackTrace, ex.InnerException);
            return await ActionResultResponseHelper.CreateInternalServerErrorAsync(req.HttpContext,
               new ServiceErrorResponse { Error = "An unexpected error occured", Message = "Please contact Evolve for additional details." });
        }
        catch (PaymentHandlerException ex)
        {
            log.LogError(ex, "Validate Payment Services PaymentHandlerException: {Message}, {Stack}, {Inner_Exception}", ex.Message);
            return await ActionResultResponseHelper.CreateInternalServerErrorAsync(req.HttpContext,
               new ServiceErrorResponse { Error = "An unexpected error occured", Message = "Please contact Evolve for additional details." });
        }
        catch (JsonException ex)
        {
            log.LogError(ex, "Validate Payment Services JsonSerializationException: {Message}, {Stack}, {Inner_Exception}", ex.Message, ex.StackTrace, ex.InnerException);
            return await ActionResultResponseHelper.CreateInternalServerErrorAsync(req.HttpContext,
               new ServiceErrorResponse { Error = "An unexpected error occured", Message = "Please contact Evolve for additional details." });
        }
        catch (Exception ex)
        {
            log.LogError(ex, "Validate Payment Services function Error: {Message}, {Stack} {Inner_Exception}", ex.Message, ex.StackTrace, ex.InnerException);
            return await ActionResultResponseHelper.CreateInternalServerErrorAsync(req.HttpContext,
                new ServiceErrorResponse { Error = "An unexpected error occured", Message = "Please contact Evolve for additional details." });
        }
    }

    private static bool IsPaymentCompleted(string lastStatus) =>
        lastStatus == RequestStatus.COMPLETED.ToString();
}