﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using SendPaymentServicesFA.Providers;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace SendPaymentServicesFA.Functions;

public class HealthCheck
{
    private readonly IHealthCheckServiceProvider _healthCheckServiceProvider;
    private readonly ILogger<HealthCheck> log;
    public HealthCheck(IHealthCheckServiceProvider healthCheckServiceProvider, ILogger<HealthCheck> logger)
    {
        _healthCheckServiceProvider= healthCheckServiceProvider;
        log = logger;
    }

    [Function("Health")]
    public async Task<IActionResult> Health(
       [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req)
    {
        log.LogInformation("Received health check request");
        HealthReport report = await _healthCheckServiceProvider.GetHealthAsync();
        return new OkObjectResult(Enum.GetName(typeof(HealthStatus), report.Status));
    }
}