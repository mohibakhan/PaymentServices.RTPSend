using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.OpenApi.Models;
using SendPaymentServicesFA.Models;
using Microsoft.Extensions.Logging;
using SendPaymentServicesFA.Helpers;
using SendPaymentServicesFA.Exceptions;
using Microsoft.Azure.Functions.Worker;
using Evolve.Digital.Core.Utilities.Http;
using SendPaymentServicesFA.Exceptions.Core;
using SendPaymentServicesFA.Interface.Adapters;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;

namespace SendPaymentServicesFA.Functions;

public class GetPayment
{
    private readonly IProblemHelper _problemHelper;
    private IPaymentCosmosDBAdapter _paymentCosmosDBService;
    private readonly ILogger<GetPayment> log;

    /// <summary>
    /// Constructor method for GetPayment
    /// </summary>
    /// <param name="httpContextAccessor"></param>
    /// <param name="telemetryClient"></param>
    public GetPayment(IPaymentCosmosDBAdapter paymentCosmosDBService,
                      IProblemHelper problemHelper,
                      ILogger<GetPayment> logger)
    {
        _paymentCosmosDBService = paymentCosmosDBService;
        _problemHelper = problemHelper;
        log = logger;
    }

    [Function("GetPayment_evolveId")]
    [OpenApiOperation(operationId: "Run", tags: new[] { "GetPayment" })]
    [OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "code", In = OpenApiSecurityLocationType.Query)]
    [OpenApiParameter(name: "evolveId", In = ParameterLocation.Path, Required = true, Type = typeof(string), Description = "The **evolveId** parameter")]
    [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Function, "get", Route = "evolveId/{evolveId}")] HttpRequest req, string evolveId)
    {
        log.LogInformation("Request received to retrieve payment by evolve Id.");

        var headers = req.Headers;

        if (headers["x-client-id"].ToString() == string.Empty
            || headers["x-merchant-id"].ToString() == string.Empty
            || string.IsNullOrWhiteSpace(evolveId))
            return await CreateProblemResponseAsync(req.HttpContext, new ValidationProblem());

        var evolvePayment = (await _paymentCosmosDBService.GetPayment(evolveId, headers)).FirstOrDefault();

        if (evolvePayment == null)
            return await ActionResultResponseHelper.CreateNotFoundAsync(req.HttpContext,
                new ServiceErrorResponse { Error = "Not found", Message = $"Request with Evolve Id {evolveId} not found." });

        return await ActionResultResponseHelper.CreateOkAsync(req.HttpContext, evolvePayment);
    }

    [Function("GetPayment_paymentReference")]
    [OpenApiOperation(operationId: "Run1", tags: new[] { "GetPayment" })]
    [OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "code", In = OpenApiSecurityLocationType.Query)]
    [OpenApiParameter(name: "paymentReference", In = ParameterLocation.Path, Required = true, Type = typeof(string), Description = "The **paymentReference** parameter")]
    [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "text/plain", bodyType: typeof(string), Description = "The OK response")]
    public async Task<IActionResult> Run1(
        [HttpTrigger(AuthorizationLevel.Function, "get", Route = "paymentReference/{paymentReference}")] HttpRequest req, string paymentReference)
    {
        log.LogInformation("\"Request received to retrieve payment by payment reference.");

        var headers = req.Headers;

        if (headers["x-client-id"].ToString() == string.Empty
            || headers["x-merchant-id"].ToString() == string.Empty
            || string.IsNullOrWhiteSpace(paymentReference))
            return await CreateProblemResponseAsync(req.HttpContext, new ValidationProblem());

        var evolvePayment = (await _paymentCosmosDBService.GetPaymentByReference(paymentReference, headers)).FirstOrDefault();

        if (evolvePayment == null)
            return await ActionResultResponseHelper.CreateNotFoundAsync(req.HttpContext,
                new ServiceErrorResponse { Error = "Not found", Message = $"Request with Payment Reference {paymentReference} not found." });

        return await ActionResultResponseHelper.CreateOkAsync(req.HttpContext, evolvePayment);
    }

    private async Task<IActionResult> CreateProblemResponseAsync(HttpContext context, Problem problem)
    {
        var traceId = _problemHelper.GetTraceId(context);
        problem.TraceId = traceId;
        problem.ReferenceCode = _problemHelper.GenerateReferenceCode(traceId);
        return await ActionResultResponseHelper.CreateAsync((HttpStatusCode)problem.Status, context, problem);
    }
}

