using System;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using System.Threading.Tasks;
using Azure.Messaging.ServiceBus;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SendPaymentServicesFA.Settings;
using SendPaymentServicesFA.Constants;
using Microsoft.Azure.Functions.Worker;
using SendPaymentServicesFA.Models.Request;
using Evolve.Digital.Shared.Models.Payments;
using SendPaymentServicesFA.Interface.Adapters;
using SendPaymentServicesFA.Interface.Services;

namespace SendPaymentServicesFA.Functions;

public class PreVaidatePayment
{
    private readonly ILogger<PreVaidatePayment> _logger;
    private readonly IPaymentCosmosDBAdapter _paymentCosmosDBService;
    private static ServiceBusClient client;
    private static ServiceBusSender sender;
    private readonly AppSettings _appSettings;
    private readonly IValidatePaymentService _validatePaymentService;

    public PreVaidatePayment(ILogger<PreVaidatePayment> logger,
        IPaymentCosmosDBAdapter paymentCosmosDBService,
        IValidatePaymentService validatePaymentService,
        IOptions<AppSettings> appSettings)
    {
        _logger = logger;
        _paymentCosmosDBService = paymentCosmosDBService;
        _validatePaymentService = validatePaymentService;
        _appSettings = appSettings.Value;
    }

    /// <summary>
    /// Reads messages from service bus subscription
    /// </summary>
    /// <param name="messages"></param>
    /// <param name="messageActions"></param>
    /// <returns></returns>
    [Function(nameof(PreVaidatePayment))]
    public async Task Run(
        [ServiceBusTrigger(topicName: "%rtpSend:AppSettings:SERVICE_BUS_TOPIC_NAME%",
                           subscriptionName: "%rtpSend:AppSettings:SERVICE_BUS_SUBSCRIPTION_NAME%",
                           Connection = "rtpSend:AppSettings:SERVICE_BUS_CONNSTRING", IsBatched =true)]
             ServiceBusReceivedMessage[] messages,
             ServiceBusMessageActions messageActions)
    {
        foreach (var message in messages)
        {
            _logger.LogInformation("Message ID: {id}", message.MessageId);
            string payload = Encoding.UTF8.GetString(message.Body);
            _logger.LogInformation($"Event received for pre validation : {payload}");
            var request = JsonConvert.DeserializeObject<RtpValidateEvent>(payload);

            // Get item from cosmos DB
            var cosmosPaymentItem = (await _paymentCosmosDBService.FindAllItemsAsync(request.Metadata.EvolveId)).FirstOrDefault();
            if (IsCreatePaymentDocument(cosmosPaymentItem))
            {
                var lastStatus = cosmosPaymentItem.StatusHistory.Last();
                if (IsDocumentUpdated(lastStatus))
                {
                    // Call Validate Payment
                    _logger.LogInformation($"Prevalidation passed. Calling validate payment endpoint for evolveId {cosmosPaymentItem.EvolveId}");
                    await _validatePaymentService.ValidatePaymentAsync(request);
                    await messageActions.CompleteMessageAsync(message);
                }
                else
                {
                    // Resubmit message -- ONLY RESUBMIT IF LAST STATUS IS ACCOUNT LOOKUP COMPLETED
                    if (IsDocumentAccountLookupCompleted(lastStatus))
                    {
                        var resubmittedMessage = new ServiceBusMessage(payload)
                        {
                            Subject = PaymentRequestConstants.PreValidatePaymentMsgSubject,
                            ScheduledEnqueueTime = DateTime.UtcNow.AddSeconds(30)
                        };

                        client = new ServiceBusClient(_appSettings.SERVICE_BUS_CONNSTRING);
                        sender = client.CreateSender(_appSettings.SERVICE_BUS_TOPIC_NAME);
                        await sender.SendMessageAsync(resubmittedMessage);
                    }
                    else
                    {
                        await messageActions.CompleteMessageAsync(message);
                    }
                }
            }
            else
            {
                _logger.LogWarning($"No transaction exists for evolve Id {request.Metadata.EvolveId}");
                await messageActions.CompleteMessageAsync(message);
            }
        }
    }

    private static bool IsCreatePaymentDocument(EvolvePaymentRequest cosmosPaymentItem) =>
                (cosmosPaymentItem != null && cosmosPaymentItem.DocumentType == PaymentRequestConstants.DocumentType);

    private static bool IsDocumentUpdated(StatusHistory lastStatus) =>
        (lastStatus.Stage == RequestStage.FRAUDSANCTIONCHECK.ToString() && lastStatus.Status == RequestStatus.ACCEPTED.ToString());

    private bool IsDocumentAccountLookupCompleted(StatusHistory lastStatus) =>
        (lastStatus.Stage == RequestStage.ACCOUNTLOOKUP.ToString() && lastStatus.Status == RequestStatus.COMPLETED.ToString());
}