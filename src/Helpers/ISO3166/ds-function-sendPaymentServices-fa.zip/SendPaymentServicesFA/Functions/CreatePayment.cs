using System;
using System.Net;
using System.Linq;
using Newtonsoft.Json;
using FluentValidation;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using SendPaymentServicesFA.Helpers;
using SendPaymentServicesFA.Interface;
using SendPaymentServicesFA.Constants;
using SendPaymentServicesFA.Exceptions;
using Microsoft.Azure.Functions.Worker;
using Evolve.Digital.Core.Utilities.Http;
using SendPaymentServicesFA.Services.Facade;
using SendPaymentServicesFA.Exceptions.Core;
using Evolve.Digital.Shared.Models.Payments;
using SendPaymentServicesFA.Models.Response;
using SendPaymentServicesFA.Interface.Adapters;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;

namespace SendPaymentServicesFA.Functions;

public class CreatePayment
{
    private readonly IPaymentCosmosDBAdapter _paymentCosmosDBService;
    private readonly IEvolvePaymentRequestHelper _evolvePaymentRequestHelper;
    private readonly IApiUserConfigCosmosAdapter _apiConfig;
    private readonly IValidator<BasicPaymentRequest> _validator;
    private readonly IProblemHelper _problemHelper;
    private readonly ILogger<CreatePayment> log;
    private readonly IPreRtpChecksFacade _facade;

    /// <summary>
    /// Constructor method for CreatePayment
    /// </summary>
    /// <param name="httpContextAccessor"></param>
    /// <param name="telemetryClient"></param>
    public CreatePayment(
        IPaymentCosmosDBAdapter paymentCosmosDBService,
        IEvolvePaymentRequestHelper evolvePaymentRequestHelper,
        IApiUserConfigCosmosAdapter apiConfig,
        IValidator<BasicPaymentRequest> validator,
        IProblemHelper problemHelper,
        ILogger<CreatePayment> logger,
        IPreRtpChecksFacade facade
        )
    {
        _paymentCosmosDBService = paymentCosmosDBService;
        _evolvePaymentRequestHelper = evolvePaymentRequestHelper;
        _apiConfig = apiConfig;
        _validator = validator;
        _problemHelper = problemHelper;
        log = logger;
        _facade = facade;
    }


    /// <summary>
    /// The function app endpoint accepts Payment Requests, Calls Validator Service and sends information over to RTP Ledger
    /// </summary>
    /// <param name="req"></param>
    /// <param name="log"></param>
    /// <returns>Ok, Accepted, BadRequest, InternalServerError</returns>
    [Function("CreatePayment")]
    [OpenApiOperation(operationId: "CreatePayment", tags: new[] { "CreatePayment" })]
    [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(BasicPaymentRequest), Description = "BasicPaymentRequest", Required = true)]
    [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(CreatePaymentResponse), Description = "The CREATED response")]
    [OpenApiResponseWithBody(statusCode: HttpStatusCode.BadRequest, contentType: "application/json", bodyType: typeof(Problem), Description = "Bad Request")]
    [OpenApiResponseWithBody(statusCode: HttpStatusCode.Conflict, contentType: "application/json", bodyType: typeof(Problem), Description = "Conflict")]
    [OpenApiResponseWithBody(statusCode: HttpStatusCode.InternalServerError, contentType: "application/json", bodyType: typeof(Problem), Description = "Internal Server Error")]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req)
    {
        try
        {
            var userRequest = await req.GetJsonBodyAsync<BasicPaymentRequest>();

            log.LogInformation($"Request body: {JsonConvert.SerializeObject(userRequest)}");

            var headers = req.Headers;
            var clientId = headers["x-client-id"].ToString();
            var merchantId = headers["x-merchant-id"].ToString();
            var subscriptionKey = headers["ocp-apim-subscription-key"].ToString();

            if (userRequest == null ||
                string.IsNullOrWhiteSpace(clientId) ||
                string.IsNullOrWhiteSpace(merchantId) ||
                string.IsNullOrWhiteSpace(subscriptionKey))
            {
                return await CreateProblemResponseAsync(req.HttpContext, new ValidationProblem());
            }

            // Validate incoming request
            var fluentValidationResult = await _validator.ValidateAsync(userRequest);
            if (!fluentValidationResult.IsValid)
            {
                return await CreateProblemResponseAsync(req.HttpContext, new ValidationProblem
                {
                    InvalidParams = fluentValidationResult.Errors.Select(e => new InvalidParams
                    {
                        Details = e.PropertyName,
                        Message = e.ErrorMessage
                    }).ToList()
                });
            }

            // Retrieve api user config
            var apiUserConfigResponse = await _apiConfig.GetApiUserConfigAsync(clientId, merchantId, subscriptionKey);

            // If there is no API config
            if (apiUserConfigResponse == null)
                return await CreateProblemResponseAsync(req.HttpContext, new ForbiddenProblem());

            // Convert Basic payment request to EvolvePaymentRequest
            var request = _evolvePaymentRequestHelper.ConvertBasicToEvolveRequest(userRequest, headers, apiUserConfigResponse.PmtHandler);

            // Find if it is a duplicate request
            var duplicateRequest = await _paymentCosmosDBService.FindIfItemDuplicateAsync(userRequest.PaymentReference, headers);

            if (duplicateRequest)
                return await CreateProblemResponseAsync(req.HttpContext, new ConflictProblem());

            var result = await _paymentCosmosDBService.CreateItemAsync(request);
            if (result == null)
                log.LogError("Payment Request document already exists.  No further action needed");

            // Perform pre - transaction checks.  Call to partner ledger and prefund ledger
            var performPreRtpSendChecks = await _facade.PerformPreRtpChecks(request);

            // Create response
            var createPaymentResponse = new CreatePaymentResponse()
            {
                PaymentReference = request.PaymentReference,
                Status = "Accepted"
            };

            log.LogInformation($"Response from CreatePayment endpoint {JsonConvert.SerializeObject(createPaymentResponse)}");

            return await ActionResultResponseHelper.CreateAcceptedAsync(req.HttpContext, createPaymentResponse);
        }
        catch (PartnerLedgerException ex)
        {
            log.LogError(ex, "Send Payment Services PartnerLedgerException: {Message}, {Stack}, {Inner_Exception}", ex.Message, ex.StackTrace, ex.InnerException);
            return await CreateProblemResponseAsync(req.HttpContext, new ValidationProblem
            {
                Detail = $"{ex.Message}"
            });
        }
        catch (PrefundLedgerException ex)
        {
            log.LogError(ex, "Send Payment Services PrefundLedgerException: {Message}, {Stack}, {Inner_Exception}", ex.Message, ex.StackTrace, ex.InnerException);
            return await CreateProblemResponseAsync(req.HttpContext, new FraudSanctionsProblem()
            {
                Title = (ex.Message == PrefundLedgerConstants.INSUFFICIENT_FUNDS) ? PrefundLedgerConstants.INSUFFICIENT_FUNDS : "Fraud/Sanctions Check failed"
            });
        }
        catch (JsonException ex)
        {
            log.LogError(ex, "Send Payment Services JsonSerializationException: {Message}, {Stack}, {Inner_Exception}", ex.Message, ex.StackTrace, ex.InnerException);
            return await CreateProblemResponseAsync(req.HttpContext, new UnexpectedProblem());
        }
        catch (Exception ex)
        {
            log.LogError(ex, "Send Payment Services function Error: {Message}, {Stack} {Inner_Exception}", ex.Message, ex.StackTrace, ex.InnerException);
            return await CreateProblemResponseAsync(req.HttpContext, new UnexpectedProblem());
        }
    }

    private async Task<IActionResult> CreateProblemResponseAsync(HttpContext context, Problem problem)
    {
        var traceId = _problemHelper.GetTraceId(context);
        problem.TraceId = traceId;
        problem.ReferenceCode = _problemHelper.GenerateReferenceCode(traceId);
        return await ActionResultResponseHelper.CreateAsync((HttpStatusCode)problem.Status, context, problem);
    }
}