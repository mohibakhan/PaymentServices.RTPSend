﻿using System.Threading.Tasks;
using SendPaymentServicesFA.Models.Request;
using SendPaymentServicesFA.Models.Response;

namespace SendPaymentServicesFA.Interface.Adapters;

public interface IPartnerLedgerCosmosDBAdapter
{
    /// <summary>
    /// Retrieve partner ledger information for an account number
    /// </summary>
    /// <param name="accountNumber"></param>
    /// <returns></returns>
    Task<PartnerLedgerResponse> GetItemAsync(string accountNumber);

    Task<PartnerLedgerRequest> CreateItemAsync(PartnerLedgerResponse partnerLedgerResponse);
}