﻿using System.Threading.Tasks;
using SendPaymentServicesFA.Models.Response;

namespace SendPaymentServicesFA.Interface.Adapters;
public interface IApiUserConfigCosmosAdapter
{
    /// <summary>
    /// Retrieves API User config
    /// </summary>
    /// <param name="clientId"></param>
    /// <param name="merchantIdm"></param>
    /// <param name="subscriptionKey"></param>
    /// <returns></returns>
    Task<ApiUserConfigResponse> GetApiUserConfigAsync(string clientId, string merchantIdm, string subscriptionKey);

    /// <summary>
    /// Retrieves API User config
    /// </summary>
    /// <param name="clientId"></param>
    /// <param name="merchantIdm"></param>
    /// <returns></returns>
    Task<ApiUserConfigResponse> GetApiUserConfigAsync(string clientId, string merchantId);
}