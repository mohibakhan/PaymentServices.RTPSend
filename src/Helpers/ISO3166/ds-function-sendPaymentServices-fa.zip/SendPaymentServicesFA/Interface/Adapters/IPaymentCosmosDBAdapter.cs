﻿using System.Threading.Tasks;
using Microsoft.Azure.Cosmos;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using Evolve.Digital.Shared.Models.Payments;

namespace SendPaymentServicesFA.Interface.Adapters;

public interface IPaymentCosmosDBAdapter
{
    /// <summary>
    /// Get Cosmos document
    /// </summary>
    /// <param name="id"></param>
    /// <param name="evolvePaymentId"></param>
    /// <returns>EvolvePaymentRequest cosmos document</returns>
    Task<EvolvePaymentRequest> GetItemAsync(string id, string evolvePaymentId);

    /// <summary>
    /// Creates new EvolvePaymentRequest Cosmos Document
    /// </summary>
    /// <param name="evolvePaymentRequest"></param>
    /// <returns>EvolvePaymentRequest Cosmos Document</returns>
    Task<EvolvePaymentRequest> CreateItemAsync(EvolvePaymentRequest evolvePaymentRequest);

    /// <summary>
    /// Updates EvolvePaymentRequest Cosmos Document
    /// </summary>
    /// <param name="evolvePaymentRequest"></param>
    /// <returns>EvolvePaymentRequest</returns>
    Task<EvolvePaymentRequest> UpdateItemAsync(EvolvePaymentRequest evolvePaymentRequest);

   /// <summary>
   /// Patch cosmos item
   /// </summary>
   /// <param name="evolvePaymentRequest"></param>
   /// <param name="patchOperations"></param>
   /// <returns></returns>
    Task<EvolvePaymentRequest> PatchItemAsync(EvolvePaymentRequest evolvePaymentRequest, List<PatchOperation> patchOperations);

    /// <summary>
    /// Finds the items based on the supplied query and evolveId parameter
    /// </summary>
    /// <param name="evolveId"></param>
    /// <returns>List of EvolvePaymentRequest</returns>
    Task<List<EvolvePaymentRequest>> FindAllItemsAsync(string evolveId);

    /// <summary>
    /// Finds the items based on the supplied query, evolveId parameter, documentType and documentSubType
    /// </summary>
    /// <param name="evolveId"></param>
    /// <returns>List of EvolvePaymentRequest</returns>
    Task<List<EvolvePaymentRequest>> FindAllItemsAsync(string evolveId, string documentType, string documentSubType);

    /// <summary>
    /// Finds the items based on the supplied query and evolveId parameter
    /// </summary>
    /// <param name="amount"></param>
    /// <returns>List of EvolvePaymentRequest</returns>
    Task<List<EvolvePaymentRequest>> FindAllItemsByAmountAsync(string amount);

    /// <summary>
    /// Find cosmos item by payment Reference
    /// </summary>
    /// <param name="paymentRef"></param>
    /// <returns>EvolvePaymentRequest</returns>
    Task<List<EvolvePaymentRequest>> FindAllItemsByaymentReferenceAsync(string paymentRef);

    /// <summary>
    /// Find duplicate payment requests
    /// </summary>
    /// <param name="paymentReference"></param>
    /// <param name="headers"></param>
    /// <returns></returns>
    Task<bool> FindIfItemDuplicateAsync(string paymentReference, IHeaderDictionary headers);

    /// <summary>
    /// Get Payment by evolveId
    /// </summary>
    /// <param name="evolveId"></param>
    /// <param name="headers"></param>
    /// <returns></returns>
    Task<List<EvolvePaymentRequest>> GetPayment(string evolveId, IHeaderDictionary headers);

    /// <summary>
    /// Get Payment by payment Reference
    /// </summary>
    /// <param name="paymentReference"></param>
    /// <param name="headers"></param>
    /// <returns></returns>
    Task<List<EvolvePaymentRequest>> GetPaymentByReference(string paymentReference, IHeaderDictionary headers);
}
