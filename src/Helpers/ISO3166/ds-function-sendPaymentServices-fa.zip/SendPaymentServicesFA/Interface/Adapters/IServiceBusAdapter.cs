﻿using System.Threading.Tasks;
using SendPaymentServicesFA.Models;

namespace SendPaymentServicesFA.Interface.Adapters;

public interface IServiceBusAdapter
{
    /// <summary>
    /// Service bus adapter for sending notifications
    /// </summary>
    Task SendMessage(ServiceBusRequest serviceBusRequest);
}
