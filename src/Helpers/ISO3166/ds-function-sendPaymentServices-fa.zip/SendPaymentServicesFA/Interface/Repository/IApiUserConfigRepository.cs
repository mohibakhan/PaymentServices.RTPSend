﻿using System.Threading.Tasks;
using SendPaymentServicesFA.Models.Response;

namespace SendPaymentServicesFA.Interface.Repository;

public interface IApiUserConfigRepository
{
    /// <summary>
    /// Get API User config for a given client and merchant Id
    /// </summary>
    /// <param name="ClientId"></param>
    /// <param name="MerchantId"></param>
    /// <returns><see cref="ApiUserConfigResponse"/></returns>
    Task<ApiUserConfigResponse> GetApiUserConfigAsync(string ClientId, string MerchantId);
}