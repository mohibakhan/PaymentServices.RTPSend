﻿using System.Threading.Tasks;
using SendPaymentServicesFA.Models.Response;

namespace SendPaymentServicesFA.Interface.Repository;

public interface IPartnerLedgerRepository
{
    /// <summary>
    /// Get Partner Ledger Information from vaccount
    /// </summary>
    /// <param name="vAccountNumber"></param>
    /// <param name="log"></param>
    /// <returns><see cref="PartnerLedgerResponse"/></returns>
    Task<PartnerLedgerResponse> PartnerLedgerVAccountLookup(string vAccountNumber);
}