﻿using System.Threading.Tasks;
using Evolve.Digital.Shared.Models.Payments;

namespace SendPaymentServicesFA.Interface.Factory;

public interface IPaymentHandler
{
    Task<bool> ProcessPayment(EvolvePaymentRequest evolvePaymentRequest);
}
