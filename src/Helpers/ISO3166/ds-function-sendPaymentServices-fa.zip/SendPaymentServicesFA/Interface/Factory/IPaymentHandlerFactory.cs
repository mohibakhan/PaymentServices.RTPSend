﻿namespace SendPaymentServicesFA.Interface.Factory;

public interface IPaymentHandlerFactory
{
    IPaymentHandler CreatePaymentHandler();
}