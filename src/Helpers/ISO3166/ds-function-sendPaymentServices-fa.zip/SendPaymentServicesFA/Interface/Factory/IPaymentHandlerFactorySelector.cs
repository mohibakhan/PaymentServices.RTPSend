﻿namespace SendPaymentServicesFA.Interface.Factory;

public interface IPaymentHandlerFactorySelector
{
    IPaymentHandlerFactory GetFactory(string paymentType);
}