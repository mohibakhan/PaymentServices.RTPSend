﻿using System.Net.Http;
using System.Threading.Tasks;
using SendPaymentServicesFA.Models.Request;

namespace SendPaymentServicesFA.Interface.Services;

public interface IValidatePaymentService
{
    Task<HttpResponseMessage> ValidatePaymentAsync(RtpValidateEvent eventNotification);
}