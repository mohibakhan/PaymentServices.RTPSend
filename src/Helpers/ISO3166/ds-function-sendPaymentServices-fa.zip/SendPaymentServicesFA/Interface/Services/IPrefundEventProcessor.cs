﻿using System.Threading.Tasks;
using Evolve.Digital.Shared.Models.Payments;
using SendPaymentServicesFA.Models.Request;

namespace SendPaymentServicesFA.Interface.Services;

public interface IPrefundEventProcessor
{
    Task<bool> ProcessEventAsync(RtpValidateEvent @event, EvolvePaymentRequest evolvePaymentRequest);
}