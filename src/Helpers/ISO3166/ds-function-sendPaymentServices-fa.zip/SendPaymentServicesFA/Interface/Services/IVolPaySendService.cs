﻿using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using SendPaymentServicesFA.Models.Request;

namespace SendPaymentServicesFA.Interface.Services;

public interface IVolPaySendService
{
    Task<HttpResponseMessage> SendTransactionAsync(VolPayRequest volPayRequest);

    Task<HttpResponseMessage> GetVolanteTokenAsync(CancellationToken cancelellationToken);
}