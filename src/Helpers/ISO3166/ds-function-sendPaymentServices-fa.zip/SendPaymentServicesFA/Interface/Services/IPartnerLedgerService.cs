﻿using System.Threading.Tasks;
using SendPaymentServicesFA.Models.Response;

namespace SendPaymentServicesFA.Interface.Services;

public interface IPartnerLedgerService
{
    Task<PartnerLedgerResponse> PartnerLedgerLookupLA(string vAccountNumber);
}