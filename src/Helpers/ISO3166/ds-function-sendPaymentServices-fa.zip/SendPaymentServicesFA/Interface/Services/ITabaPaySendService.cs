﻿using System.Net.Http;
using System.Threading.Tasks;
using Evolve.Digital.Shared.Models.Payments;

namespace SendPaymentServicesFA.Interface.Services;

public interface ITabaPaySendService
{
    /// <summary>
    /// Send Transaction to TabaPay
    /// </summary>
    /// <param name="tabaPayRequest"></param>
    /// <returns></returns>
    Task<HttpResponseMessage> SendTransaction(TabapayPaymentRequest tabapayPaymentRequest);
}