﻿using System.Threading.Tasks;
using Evolve.Digital.Shared.Models;

namespace SendPaymentServicesFA.Interface.Services;
public interface IServiceBusMessageService
{
    Task SendMessageToServiceBusAsync(ServiceBusContentModel serviceBusMessage, string subject);
}