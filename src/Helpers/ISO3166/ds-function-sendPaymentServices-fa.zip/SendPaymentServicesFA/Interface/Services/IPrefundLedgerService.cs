﻿using System.Net.Http;
using System.Threading.Tasks;
using SendPaymentServicesFA.Models.Business;

namespace SendPaymentServicesFA.Interface.Services;

public interface IPrefundLedgerService
{
    /// <summary>
    /// Fraud Sanctions Check tp Prefund Ledger
    /// </summary>
    /// <param name="businessEvolvePaymentRequest"></param>
    /// <returns></returns>
    Task<HttpResponseMessage> SendFraudSanctionsCheck(BusinessEvolvePaymentRequest businessEvolvePaymentRequest);

    /// <summary>
    /// Notifify RTP Ledger of TabaPayResponse
    /// </summary>
    /// <param name="evolvePaymentRequest"></param>
    /// <returns></returns>
    Task<HttpResponseMessage> SendPaymentStatus(BusinessEvolvePaymentRequest businessEvolvePaymentRequest);
}