﻿using System.Threading.Tasks;
using SendPaymentServicesFA.Models.Request;
using Evolve.Digital.Shared.Models.Payments;

namespace SendPaymentServicesFA.Interface;

public interface IEventHandler
{
    Task<bool> HandleEventAsync(RtpValidateEvent ev, EvolvePaymentRequest evolvePaymentRequest);
}