﻿using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using Evolve.Digital.Shared.Models.Payments;
using SendPaymentServicesFA.Models.Business;

namespace SendPaymentServicesFA.Interface;

public interface IEvolvePaymentRequestHelper
{
    /// <summary>
    /// Convert BasicPaymentRequest to EvolvePaymentRequest
    /// </summary>
    /// <param name="basicPaymentRequest"></param>
    /// <param name="headers"></param>
    /// <returns><see cref="EvolvePaymentRequest"/></returns>
    EvolvePaymentRequest ConvertBasicToEvolveRequest(BasicPaymentRequest basicPaymentRequest, IHeaderDictionary headers, string documentSubType);

    /// <summary>
    /// Converts <see cref="EvolvePaymentRequest"/>  to <see cref="BusinessEvolvePaymentRequest"/>
    /// </summary>
    /// <param name="request"></param>
    /// <returns><see cref="BusinessEvolvePaymentRequest"/></returns>
    BusinessEvolvePaymentRequest ConvertToBusinessDocument(EvolvePaymentRequest request);

    /// <summary>
    /// Checks whether additional info field on status has a specific value
    /// </summary>
    /// <param name="statusHistory"></param>
    /// <param name="additionalInfo"></param>
    /// <returns>true if found, false if not found</returns>
    bool ContainsAdditionalInfo(List<StatusHistory> statusHistory, string additionalInfo);
}