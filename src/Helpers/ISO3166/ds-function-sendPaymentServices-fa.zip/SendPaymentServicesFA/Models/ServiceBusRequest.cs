﻿namespace SendPaymentServicesFA.Models;

public class ServiceBusRequest
{
    /// <summary>
    /// Gets or sets the content of the message as a JSON string
    /// </summary>
    public string Content { get; set; }

    /// <summary>
    /// Gets or sets the name of the queue to send the message to
    /// </summary>
    public string QueueName { get; set; }

    /// <summary>
    /// Gets or sets the subject for the message
    /// </summary>
    public string Subject { get; set; }
}