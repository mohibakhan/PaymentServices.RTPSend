﻿using Newtonsoft.Json;

namespace SendPaymentServicesFA.Models;

public class ValidatorServiceErrorResponse
{
    [JsonProperty("error")]
    public string Error { get; set; }
    [JsonProperty("message")]
    public object Message { get; set; }
}