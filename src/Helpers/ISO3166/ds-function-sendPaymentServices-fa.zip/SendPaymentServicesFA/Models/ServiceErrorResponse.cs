﻿using Newtonsoft.Json;

namespace SendPaymentServicesFA.Models;

public class ServiceErrorResponse
{
    [JsonProperty("error")]
    public string Error { get; set; }
    [JsonProperty("message")]
    public string Message { get; set; }
    [JsonProperty("additionalInfo", NullValueHandling = NullValueHandling.Ignore)]
    public object AddInfo { get; set; }
}