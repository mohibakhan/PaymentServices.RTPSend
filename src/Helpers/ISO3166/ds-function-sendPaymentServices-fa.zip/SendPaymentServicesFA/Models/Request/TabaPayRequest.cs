﻿using Evolve.Digital.Shared.Models.Payments;
using Newtonsoft.Json;

namespace SendPaymentServicesFA.Models.Request;
public class TabaPayRequest : TabapayPaymentRequest
{
    [JsonProperty("softDescriptor")]
    public SoftDescriptor SoftDescriptor { get; set; }
}

public class SoftDescriptor
{
    [JsonProperty("name")]
    public string Name { get; set; }

    [JsonProperty("email")]
    public string Email { get; set; }

    [JsonProperty("phone")]
    public Phone Phone { get; set; }

    [JsonProperty("address")]
    public TabapayAddress Address { get; set; }
}