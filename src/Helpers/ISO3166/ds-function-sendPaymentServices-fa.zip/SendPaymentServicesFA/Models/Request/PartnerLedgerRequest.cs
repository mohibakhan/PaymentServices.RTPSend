﻿using Newtonsoft.Json;

namespace SendPaymentServicesFA.Models.Request;

public class PartnerLedgerRequest
{
    [JsonProperty("id")]
    public string Id { get; set; }

    [JsonProperty("vAccountNumber")]
    public string VAccountNumber { get; set; }

    [JsonProperty("fboAccount")]

    public string FboAccount { get; set; }

    [JsonProperty("fboAccountName")]

    public string FboAccountName { get; set; }

    [JsonProperty("CIFNO")]

    public string CifNo { get; set; }

    [JsonProperty("taxId")]
    public string TaxId { get; set; }

    [JsonProperty("userIsBusiness")]
    public string UserIsBusiness { get; set; }

    [JsonProperty("accountStatus")]
    public string AccountStatus { get; set; }

    [JsonProperty("errorMessage")]
    public string ErrorMessage { get; set; }
}