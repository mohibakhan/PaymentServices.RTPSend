﻿using System.Collections.Generic;

namespace SendPaymentServicesFA.Models.Request;

public class VolPayRequest
{
    public List<PmtDtl> PmtDtls { get; set; }
    public List<Dbtr> Dbtr { get; set; }
    public List<DbtrAcct> DbtrAcct { get; set; }
    public List<DbtrAgt> DbtrAgt { get; set; }
    public List<InitiatingParty> InitiatingParty { get; set; }
    public List<CdtrAgtModel> CdtrAgt { get; set; }
    public List<Cdtr> Cdtr { get; set; }
    public List<CdtrAcctModel> CdtrAcct { get; set; }
}

public class PmtDtl
{
    public string ValueDt { get; set; }
    public string Amt { get; set; }
    public string Ccy { get; set; }
    public string MsgTyp { get; set; }
    public string LclInstrm { get; set; }
    public string CtgyPurp { get; set; }
    public string ReqExDt { get; set; }
    public string TxId { get; set; }
    public string UETR { get; set; }
}

public class Dbtr
{
    public string AcctNm { get; set; }
}

public class DbtrAcct
{
    public string AcctNb { get; set; }
}
public class DbtrAgt
{
    public string MmbId { get; set; }
}

public class InitiatingParty
{
    public string Nm { get; set; }
    public string OthrId { get; set; }
}

public class CdtrAgtModel
{
    public string CdtrAgtMmbID { get; set; }
}

public class Cdtr
{
    public string CdtrNm { get; set; }
}

public class CdtrAcctModel
{
    public string CdtrAcct { get; set; }
    public string OthrId { get; set; }
    public string PrxyId { get; set; }
}