﻿using Newtonsoft.Json;

namespace SendPaymentServicesFA.Models.Request;

public class FraudSanctionsRequest
{
    [JsonProperty("id")]
    public string Id { get; set; }
    [JsonProperty("name")]
    public string Name { get; set; }
}