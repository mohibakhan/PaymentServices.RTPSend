﻿using System;
using Newtonsoft.Json;

namespace SendPaymentServicesFA.Models.Request;

public class RtpValidateEvent
{
    [JsonProperty("__type")]
    public string Type { get; set; }

    [JsonProperty("event")]
    public string Event { get; set; }

    [JsonProperty("subject")]
    public string Subject { get; set; }

    [JsonProperty("_deliveryId")]
    public string DeliveryId { get; set; }

    [JsonProperty("description")]
    public string Description { get; set; }

    [JsonProperty("code")]
    public int? Code { get; set; }

    [JsonProperty("metadata")]
    public EvolveMetadata Metadata { get; set; }

    [JsonProperty("to")]
    public To To { get; set; }

    [JsonProperty("firstSeenAt")]
    public string FirstSeenAt { get; set; }

    [JsonProperty("effectiveAt")]
    public string EffectiveAt { get; set; }

    [JsonProperty("subscribers")]
    public Subscriber[] Subscribers { get; set; }
}

public class EvolveMetadata
{
    public string EvolveId { get; set; }
}

public class To
{
    [JsonProperty("__type")]
    public string Type { get; set; }

    [JsonProperty("account")]
    public string Account { get; set; }

    [JsonProperty("accountType")]
    public string AccountType { get; set; }

    [JsonProperty("accountNumber")]
    public string AccountNumber { get; set; }

    [JsonProperty("bankIdentifierType")]
    public string BankIdentifierType { get; set; }

    [JsonProperty("bankIdentifier")]
    public string BankIdentifier { get; set; }

    [JsonProperty("metadata")]
    public ToMetadata Metadata { get; set; }
}

public partial class ToMetadata
{
    [JsonProperty("aggregator")]
    public string Aggregator { get; set; }

    [JsonProperty("platform")]
    public string Platform { get; set; }
}

public partial class Subscriber
{
    [JsonProperty("webhookUrl")]
    public string WebhookUrl { get; set; }

    [JsonProperty("emailNotification")]
    public string EmailNotification { get; set; }

    [JsonProperty("createdAt")]
    public string CreatedAt { get; set; }

    [JsonProperty("updatedAt")]
    public string UpdatedAt { get; set; }
}