﻿using Newtonsoft.Json;

namespace SendPaymentServicesFA.Models.Request;

public class ValidatePaymentRequest
{
    [JsonProperty("id")]
    public string Id { get; set; }
    [JsonProperty("evolveId")]
    public string EvolveId { get; set; }

    [JsonProperty("status")]
    public string Status { get; set; }
}