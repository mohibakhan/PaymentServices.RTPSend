﻿using Newtonsoft.Json;
using System.ComponentModel;
using System.Collections.Generic;
using Evolve.Digital.Shared.Models.Payments;

namespace SendPaymentServicesFA.Models.Business;

public class BusinessEvolvePaymentRequest : BasicPaymentRequest
{
    [JsonProperty("evolveId")]
    public string EvolveId { get; set; }

    [JsonProperty("createdTimeStamp")]
    public string CreatedTimeStamp { get; set; }

    [JsonProperty("modifiedTimeStamp")]
    public string ModifiedTimeStamp { get; set; }

    [JsonProperty("tabaPayTransactionId")]
    public string TabaPayTransactionId { get; set; } 

    [JsonProperty("tabaPayReferenceId")]
    public string TabaPayReferenceId { get; set; } 

    [JsonProperty("paymentCurrency")]
    public string PaymentCurrency { get; set; }

    [JsonProperty("clientId")]
    public string ClientId { get; set; }

    [JsonProperty("merchantId")]
    public string MerchantId { get; set; }

    [JsonProperty("gluId")]
    public string GluId { get; set; }

    [JsonProperty("fintechId")]
    public string FintechId { get; set; }

    [JsonProperty("statusHistory")]
    [Description("Store status and status datetime")]
    public List<BusinessRequestStatusHistory> StatusHistory { get; set; }

    [JsonProperty("valueDate")]
    public string ValueDate { get; set; } = string.Empty;

    [JsonProperty("fboAccount")]
    public string FboAccountNumber { get; set; }

    [JsonProperty("fboAccountName")]
    public string FboAccountName { get; set; }

    [JsonProperty("taxId")]
    public string TaxId { get; set; }

    [JsonProperty("userIsBusiness")]
    public bool UserIsBusiness { get; set; }
}

public class BusinessRequestStatusHistory
{
    [JsonProperty("status")]
    public string Status { get; set; } = string.Empty;

    [JsonProperty("statusDate")]
    public string StatusDate { get; set; } = string.Empty;
}