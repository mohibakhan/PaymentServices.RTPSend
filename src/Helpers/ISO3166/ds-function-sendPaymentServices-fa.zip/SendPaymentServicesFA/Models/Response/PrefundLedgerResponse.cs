﻿using Newtonsoft.Json;
using SendPaymentServicesFA.Converters;

namespace SendPaymentServicesFA.Models.Response;

public class PrefundLedgerResponse
{
    [JsonProperty("evolveId")]
    public string EvolveId { get; set; }

    [JsonProperty("fintechId")]
    public string FintechId { get; set; }

    [JsonProperty("transactionId")]
    public string TransactionId { get; set; }

    [JsonProperty("gluId")]
    public string GluId { get; set; }

    [JsonProperty("gluId_s")]
    public string GluId_s { get; set; }

    [JsonProperty("gluId_d")]
    public string GluId_d { get; set; }

    [JsonProperty("statusCode")]
    public string StatusCode { get; set; }
}

public class PrefundErrorResponse
{
    [JsonProperty("name")]
    public string Name { get; set; }

    [JsonProperty("message")]
    public string Message { get; set; }

    [JsonProperty("code")]
    public int Code { get; set; }

    [JsonProperty("type")]
    public string Type { get; set; }

    [JsonProperty("data")]
    [JsonConverter(typeof(PrefundDataConverter))]
    public object Data { get; set; }
}