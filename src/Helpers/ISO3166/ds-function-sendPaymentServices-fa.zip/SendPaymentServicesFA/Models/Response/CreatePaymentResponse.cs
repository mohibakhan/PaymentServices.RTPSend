﻿using Newtonsoft.Json;

namespace SendPaymentServicesFA.Models.Response;

public class CreatePaymentResponse
{
    [JsonProperty("paymentReference")]
    public string PaymentReference { get; set; }

    [JsonProperty("status")]
    public string Status { get; set; }
}