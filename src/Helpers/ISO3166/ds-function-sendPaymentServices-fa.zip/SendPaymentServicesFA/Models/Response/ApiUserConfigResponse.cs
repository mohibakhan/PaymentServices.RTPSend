﻿using Newtonsoft.Json;

namespace SendPaymentServicesFA.Models.Response;

public class ApiUserConfigResponse
{
    [JsonProperty("fintechName")]
    public string FintechName { get; set; }

    [JsonProperty("pmtHandler")]
    public string PmtHandler { get; set; }

    [JsonProperty("notifyTo")]
    public string NotifyTo { get; set; }

    [JsonProperty("notifyCc")]
    public string NotifyCc { get; set; }

    [JsonProperty("clientId")]
    public string ClientId { get; set; }

    [JsonProperty("merchantId")]
    public string MerchantId { get; set; }

    [JsonProperty("subscriptionKey")]
    public string SubscriptionKey { get; set; }

    [JsonProperty("paymentReference")]
    public string PaymentReference { get; set; }

    [JsonProperty("status")]
    public string Status { get; set; }

    [JsonProperty("pmtEventNotificationWebhookUrl")]
    public string PmtEventNotificationWebhookUrl { get; set; }
}