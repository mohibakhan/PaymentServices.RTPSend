﻿namespace SendPaymentServicesFA.Models.Response;

public class VolPayTokenResponse
{
    public string UsrId { get; set; }
    public string SsnTkn { get; set; }
}