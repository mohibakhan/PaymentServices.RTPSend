﻿using Newtonsoft.Json;

namespace SendPaymentServicesFA.Models.Response;

public class TabaPayResponse
{
    [JsonProperty("SC")]
    public int Sc { get; set; }

    [JsonProperty("EC")]
    public string Ec { get; set; }

    [JsonProperty("transactionID")]
    public string TransactionId { get; set; }

    [JsonProperty("network")]
    public string Network { get; set; }

    [JsonProperty("networkRC")]
    public string NetworkRc { get; set; }

    [JsonProperty("networkID")]
    public string NetworkId { get; set; }

    [JsonProperty("status")]
    public string Status { get; set; }

    [JsonProperty("approvalCode")]
    public string ApprovalCode { get; set; }
}