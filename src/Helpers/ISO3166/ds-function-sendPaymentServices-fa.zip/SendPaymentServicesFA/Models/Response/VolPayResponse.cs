﻿namespace SendPaymentServicesFA.Models.Response;

public class VolPayResponse
{
    public PmtDtls PmtDtls { get; set; }
}

public class PmtDtls
{
    public string OrgPmtRef { get; set; }
    public string BkAssgndRef { get; set; }
    public string StsCd { get; set; }
    public string Desc { get; set; }
}