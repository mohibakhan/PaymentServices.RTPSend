﻿using Newtonsoft.Json;

namespace SendPaymentServicesFA.Models.Response;

public class PartnerLedgerResponse
{
    [JsonProperty("vAccountNumber")]
    public string VAccountNumber { get; set; }

    [JsonProperty("fboAccount")]

    public string FboAccount { get; set; }

    [JsonProperty("fboAccountName")]

    public string FboAccountName { get; set; }

    [JsonProperty("CIFNO")]

    public string CifNo { get; set; }

    [JsonProperty("taxId")]
    public string TaxId { get; set; }

    [JsonProperty("userIsBusiness")]
    public string UserIsBusiness { get; set; }

    [JsonProperty("isBusinessUser")]
    public bool IsBusinessUser
    {
        get { return UserIsBusiness != "0"; }
    }

    [JsonProperty("accountStatus")]
    public string AccountStatus { get; set; }

    [JsonProperty("errorMessage")]
    public string ErrorMessage { get; set; }
}