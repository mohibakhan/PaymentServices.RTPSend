﻿using System;
using System.Net;
using SendPaymentServicesFA.Constants;
using SendPaymentServicesFA.Exceptions.Core;

namespace SendPaymentServicesFA.Exceptions;

internal class FraudSanctionsProblem : Problem
{
    public FraudSanctionsProblem() : base()
    {
        Type = new Uri(ProblemTypes.Base + "fraudsanctionscheck");
        Title = "Fraud/Sanctions Check failed";
        Detail = "Could not complete payment.  Please report this error to our support team with the 'referenceCode'";
        Status = (int)HttpStatusCode.InternalServerError;
    }
}