﻿using System;
using System.Net;
using System.Diagnostics.CodeAnalysis;
using SendPaymentServicesFA.Constants;
using SendPaymentServicesFA.Exceptions.Core;

namespace SendPaymentServicesFA.Exceptions;

[ExcludeFromCodeCoverage]
public class ConflictProblem : Problem
{
    public ConflictProblem() : base()
    {
        Type = new Uri(ProblemTypes.Base + "conflict");
        Title = "Conflict Problem";
        Detail = "The request cannot be processed. The payment reference sent with this request already exists.";
        Status = (int)HttpStatusCode.Conflict;
    }
}