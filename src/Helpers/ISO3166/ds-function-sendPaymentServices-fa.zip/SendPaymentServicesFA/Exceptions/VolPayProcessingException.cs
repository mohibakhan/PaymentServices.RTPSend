﻿using System;
using System.Runtime.Serialization;

namespace SendPaymentServicesFA.Exceptions;

[Serializable]
internal class VolPayProcessingException : Exception
{
    public VolPayProcessingException()
    {
    }

    public VolPayProcessingException(string message) : base(message)
    {
    }

    public VolPayProcessingException(string message, Exception innerException) : base(message, innerException)
    {
    }

    protected VolPayProcessingException(SerializationInfo info, StreamingContext context) : base(info, context)
    {
    }
}