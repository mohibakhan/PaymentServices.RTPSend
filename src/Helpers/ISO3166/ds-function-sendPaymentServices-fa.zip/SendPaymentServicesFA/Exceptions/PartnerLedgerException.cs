﻿using System;
using System.Runtime.Serialization;

namespace SendPaymentServicesFA.Exceptions;

[Serializable]
internal class PartnerLedgerException : Exception
{
    public PartnerLedgerException()
    {
    }

    public PartnerLedgerException(string message) : base(message)
    {
    }

    public PartnerLedgerException(string message, Exception innerException) : base(message, innerException)
    {
    }

    protected PartnerLedgerException(SerializationInfo info, StreamingContext context) : base(info, context)
    {
    }
}