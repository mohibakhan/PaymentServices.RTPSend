﻿using System;
using System.Runtime.Serialization;

namespace SendPaymentServicesFA.Exceptions;

public class CosmosGetException : Exception
{
    public CosmosGetException()
    {
    }

    public CosmosGetException(string message) : base(message)
    {
    }

    public CosmosGetException(string message, Exception innerException) : base(message, innerException)
    {
    }

    protected CosmosGetException(SerializationInfo info, StreamingContext context) : base(info, context)
    {
    }
}
