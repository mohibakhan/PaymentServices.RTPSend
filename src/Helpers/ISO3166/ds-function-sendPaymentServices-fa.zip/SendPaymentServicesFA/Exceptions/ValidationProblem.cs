﻿using System;
using System.Net;
using System.Diagnostics.CodeAnalysis;
using SendPaymentServicesFA.Constants;
using SendPaymentServicesFA.Exceptions.Core;

namespace SendPaymentServicesFA.Exceptions;

[ExcludeFromCodeCoverage]
public class ValidationProblem : Problem
{
    public ValidationProblem() : base()
    {
        Type = new Uri(ProblemTypes.Base + "validation");
        Title = "Validation Problem";
        Detail = "The request did not pass validation.  Make sure request is not null and all required fields and headers are present.";
        Status = (int)HttpStatusCode.BadRequest;
    }
}