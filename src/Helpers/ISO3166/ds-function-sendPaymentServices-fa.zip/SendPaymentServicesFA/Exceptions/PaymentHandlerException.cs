﻿using System;
using System.Runtime.Serialization;

namespace SendPaymentServicesFA.Exceptions;

[Serializable]
internal class PaymentHandlerException : Exception
{
    public PaymentHandlerException()
    {
    }

    public PaymentHandlerException(string message) : base(message)
    {
    }

    public PaymentHandlerException(string message, Exception innerException) : base(message, innerException)
    {
    }

    protected PaymentHandlerException(SerializationInfo info, StreamingContext context) : base(info, context)
    {
    }
}