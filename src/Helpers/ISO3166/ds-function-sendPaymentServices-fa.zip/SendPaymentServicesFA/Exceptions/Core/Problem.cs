﻿using System;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace SendPaymentServicesFA.Exceptions.Core;

public class Problem
{
    [JsonRequired]
    [JsonProperty("type")]
    public Uri Type { get; set; }

    [JsonRequired]
    [JsonProperty("title")]
    public string Title { get; set; }

    [JsonRequired]
    [JsonProperty("detail")]
    public string Detail { get; set; }

    [JsonRequired]
    [JsonProperty("status")]
    public int Status { get; set; }

    [JsonProperty("traceId")]
    public string TraceId { get; set; }

    [JsonRequired]
    [JsonProperty("referenceCode")]
    public string ReferenceCode { get; set; }

    [JsonProperty("invalidParams", NullValueHandling = NullValueHandling.Ignore)]
    public List<InvalidParams> InvalidParams { get; set; }
}

public class InvalidParams
{
    [JsonRequired]
    [JsonProperty("message")]
    public string Message { get; set; }

    [JsonRequired]
    [JsonProperty("details")]
    public string Details { get; set; }
}