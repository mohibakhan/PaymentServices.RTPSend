﻿using System;
using System.Runtime.Serialization;

namespace SendPaymentServicesFA.Exceptions;

[Serializable]
internal class TabaPayProcessingException : Exception
{
    public TabaPayProcessingException()
    {
    }

    public TabaPayProcessingException(string message) : base(message)
    {
    }

    public TabaPayProcessingException(string message, Exception innerException) : base(message, innerException)
    {
    }

    protected TabaPayProcessingException(SerializationInfo info, StreamingContext context) : base(info, context)
    {
    }
}