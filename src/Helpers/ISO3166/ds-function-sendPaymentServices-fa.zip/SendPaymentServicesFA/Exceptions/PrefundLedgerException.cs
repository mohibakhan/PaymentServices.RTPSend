﻿using System;
using System.Runtime.Serialization;

namespace SendPaymentServicesFA.Exceptions;

[Serializable]
internal class PrefundLedgerException : Exception
{
    public PrefundLedgerException()
    {
    }

    public PrefundLedgerException(string message) : base(message)
    {
    }

    public PrefundLedgerException(string message, Exception innerException) : base(message, innerException)
    {
    }

    protected PrefundLedgerException(SerializationInfo info, StreamingContext context) : base(info, context)
    {
    }
}