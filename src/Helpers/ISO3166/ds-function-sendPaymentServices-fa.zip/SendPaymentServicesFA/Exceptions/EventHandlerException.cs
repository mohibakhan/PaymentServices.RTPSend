﻿using System;
using System.Runtime.Serialization;

namespace SendPaymentServicesFA.Exceptions;

[Serializable]
internal class EventHandlerException : Exception
{
    public EventHandlerException()
    {
    }

    public EventHandlerException(string message) : base(message)
    {
    }

    public EventHandlerException(string message, Exception innerException) : base(message, innerException)
    {
    }

    protected EventHandlerException(SerializationInfo info, StreamingContext context) : base(info, context)
    {
    }
}