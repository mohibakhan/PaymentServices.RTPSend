﻿using System;
using System.Net;
using System.Diagnostics.CodeAnalysis;
using SendPaymentServicesFA.Constants;
using SendPaymentServicesFA.Exceptions.Core;

namespace SendPaymentServicesFA.Exceptions;

[ExcludeFromCodeCoverage]
public class ForbiddenProblem : Problem
{
    public ForbiddenProblem() : base()
    {
        Type = new Uri(ProblemTypes.Base + "forbidden");
        Title = "Forbidden Problem";
        Detail = "The request cannot be processed. Please report this error to our support team with the 'referenceCode'";
        Status = (int)HttpStatusCode.BadRequest;
    }
}