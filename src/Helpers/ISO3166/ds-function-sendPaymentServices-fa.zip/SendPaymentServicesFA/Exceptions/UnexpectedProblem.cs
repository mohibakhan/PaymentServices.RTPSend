﻿using System;
using System.Net;
using System.Diagnostics.CodeAnalysis;
using SendPaymentServicesFA.Constants;
using SendPaymentServicesFA.Exceptions.Core;

namespace SendPaymentServicesFA.Exceptions;

[ExcludeFromCodeCoverage]
public class UnexpectedProblem : Problem
{
    public UnexpectedProblem() : base()
    {
        Type = new Uri(ProblemTypes.Base + "unexpected");
        Title = "Unexpected Problem";
        Detail = "Something unexpected happened.  Please report this error to our support team with the 'referenceCode'";
        Status = (int)HttpStatusCode.InternalServerError;
    }
}