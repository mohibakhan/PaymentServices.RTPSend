using System;
using System.Linq;
using Azure.Identity;
using FluentValidation;
using System.Threading.Tasks;
using FluentValidation.AspNetCore;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using SendPaymentServicesFA.Helpers;
using SendPaymentServicesFA.Settings;
using SendPaymentServicesFA.Services;
using SendPaymentServicesFA.Interface;
using System.Diagnostics.CodeAnalysis;
using SendPaymentServicesFA.Providers;
using Microsoft.Azure.Functions.Worker;
using SendPaymentServicesFA.Validators;
using SendPaymentServicesFA.Repositories;
using Microsoft.Extensions.Configuration;
using SendPaymentServicesFA.Services.Facade;
using SendPaymentServicesFA.Services.Events;
using SendPaymentServicesFA.Services.Factory;
using SendPaymentServicesFA.Interface.Factory;
using Microsoft.Extensions.DependencyInjection;
using SendPaymentServicesFA.Interface.Adapters;
using Evolve.Digital.Azure.ApplicationInsights;
using SendPaymentServicesFA.Interface.Services;
using SendPaymentServicesFA.Interface.Repository;
using Microsoft.ApplicationInsights.Extensibility;
using SendPaymentServicesFA.Repositories.Adapters;
using SendPaymentServicesFA.Services.Facade.SubSystems;
using Evolve.Digital.Azure.ApplicationInsights.TelemetryInitializers;

namespace SendPaymentServicesFA;


/// <summary>
/// Main program class.
/// </summary>
[ExcludeFromCodeCoverage]
public static class Program
{
    /// <summary>
    /// Main entry point for the function app.
    /// </summary>
    /// <param name="args">The application arguments.</param>
    /// <returns>A task.</returns>
    public static Task Main(string[] args)
    {
        var host = new HostBuilder()
            .ConfigureAppConfiguration(SetupAppConfiguration)
            .ConfigureFunctionsWebApplication()
            .ConfigureServices(services =>
            {
                DependencyInjection(services);
                InitializeAppSettings(services);
            })
            .ConfigureLogging(logging =>
            {
                logging.Services.Configure<LoggerFilterOptions>(options =>
                {
                    LoggerFilterRule defaultRule = options.Rules.FirstOrDefault(rule => rule.ProviderName
                        == "Microsoft.Extensions.Logging.ApplicationInsights.ApplicationInsightsLoggerProvider");
                    if (defaultRule is not null)
                    {
                        options.Rules.Remove(defaultRule);
                    }
                });
            })
            .Build();

        return host.RunAsync();
    }

    private static void SetupAppConfiguration(IConfigurationBuilder builder)
    {
        // Need this first to pull the settings from the Function App configuration
        builder.AddEnvironmentVariables();
        var settings = builder.Build();
        var appConfigUrl = settings["AppConfig:Endpoint"];
        var azureClientId = settings["AZURE_CLIENT_ID"];

        if (!string.IsNullOrWhiteSpace(appConfigUrl) && !string.IsNullOrWhiteSpace(azureClientId))
        {
            var credentialOptions = new DefaultAzureCredentialOptions();
            credentialOptions.ManagedIdentityClientId = azureClientId;
            var credential = new DefaultAzureCredential(credentialOptions);

            builder.AddAzureAppConfiguration(options =>
            {
                options.Select("rtpSend:*");
                options.Select("telemetry:*");
                options.Connect(new Uri(appConfigUrl), credential)
                    .ConfigureKeyVault(kv => { kv.SetCredential(credential); });
            });
        }

        builder
            .SetBasePath(Environment.CurrentDirectory)
            .AddJsonFile("local.settings.json", true, false);
    }

    private static void InitializeAppSettings(IServiceCollection services)
    {
        services.AddOptions<AppSettings>().Configure<IConfiguration>((settings, configuration) =>
        {
            configuration.GetSection("rtpSend:AppSettings").Bind(settings);
        });

        services.AddOptions<TelemetryAppSettings>().Configure<IConfiguration>((settings, configuration) =>
        {
            configuration.GetSection("telemetry").Bind(settings);
        });
    }
    private static void DependencyInjection(IServiceCollection services)
    {
        services.AddApplicationInsightsTelemetryWorkerService();
        services.ConfigureFunctionsApplicationInsights();

        services.AddSingleton<ITelemetryInitializer, HttpTelemetryInitializer>();

        // Inject service dependencies
        services.AddTransient<IValidatePaymentService, ValidatePaymentService>();
        services.AddSingleton<IPaymentCosmosDBAdapter, PaymentCosmosDBAdapter>();
        services.AddSingleton<IPartnerLedgerCosmosDBAdapter, PartnerLedgerCosmosDBAdapter>();
        services.AddSingleton<IApiUserConfigCosmosAdapter, ApiUserConfigAdapter>();
        services.AddSingleton<IEvolvePaymentRequestHelper, EvolvePaymentRequestHelper>();
        services.AddSingleton<IServiceBusAdapter, ServiceBusAdapter>();
        services.AddTransient<IServiceBusMessageService, ServiceBusMessageService>();
        services.AddTransient<IApiUserConfigRepository, ApiUserConfigRepository>();
        services.AddTransient<IPartnerLedgerRepository, PartnerLedgerRepository>();
        services.AddTransient<IPrefundLedgerService, PrefundLedgerSystem>();
        services.AddSingleton<IProblemHelper, ProblemHelper>();
        services.AddSingleton<IHealthCheckServiceProvider, HealthCheckServiceProvider>();

        // Register event handlers
        services.AddSingleton<IEventHandler, AccountActionRequiredEventHandler>();
        services.AddSingleton<IEventHandler, KYCActionRequiredEventHandler>();
        services.AddSingleton<IEventHandler, KYCFailedEventHandler>();
        services.AddSingleton<IEventHandler, TMSActionRequiredEventHandler>();
        services.AddSingleton<IEventHandler, TMSCompletedEventHandler>();

        // Register EventProcessor
        services.AddSingleton<IPrefundEventProcessor>(provider =>
        {
            var eventProcessor = new PrefundEventProcessor(provider.GetRequiredService<ILogger<PrefundEventProcessor>>(), provider.GetRequiredService<IPaymentCosmosDBAdapter>());
            // Register event handlers with EventProcessor
            foreach (var handler in provider.GetServices<IEventHandler>())
            {
                eventProcessor.RegisterEventHandler(handler.GetType().Name.Replace("EventHandler",""), handler);
            }
            return eventProcessor;
        });

        services.AddSingleton<PartnerLedgerSystem>();
        services.AddSingleton<PrefundLedgerSystem>();
        services.AddScoped<IPreRtpChecksFacade, PreRtpChecksFacade>();

        // Add services to the container.
        services.AddSingleton<IPaymentHandlerFactory, TabaPayHandlerFactory>();
        services.AddSingleton<IPaymentHandlerFactory, VolPayHandlerFactory>();
        services.AddSingleton<IPaymentHandlerFactorySelector, PaymentHandlerFactorySelector>();

        services.AddFluentValidationAutoValidation();
        services.AddFluentValidationClientsideAdapters();
        services.AddValidatorsFromAssemblyContaining<BasicPaymentRequestValidator>();


        // This is necessary for the IHttpClientFactory
        services.AddHttpContextAccessor();
        services.AddHttpClient();
        services.AddLogging();

        // Add health checks
        services.AddHealthChecks();
    }
}