﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace SendPaymentServicesFA.Converters;

public class PrefundDataConverter : JsonConverter
{
    public override bool CanConvert(Type objectType)
    {
        // We want to handle both strings and JObject
        return objectType == typeof(string) || objectType == typeof(JObject);
    }

    public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
    {
        if (reader.TokenType == JsonToken.String)
        {
            // If it's a string, just return the string
            return reader.Value.ToString();
        }
        else if (reader.TokenType == JsonToken.StartObject)
        {
            // If it's an object, deserialize it to a JObject
            JObject obj = JObject.Load(reader);
            return obj;
        }
        else
        {
            throw new JsonSerializationException("Unexpected token type: " + reader.TokenType);
        }
    }

    public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
    {
        throw new NotImplementedException();
    }
}