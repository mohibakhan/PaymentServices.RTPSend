﻿using Evolve.Digital.Shared.Models;
using Evolve.Digital.Shared.Models.Payments;

namespace SendPaymentServicesFA.Helpers;

public class ServiceBusHelper
{
    public static ServiceBusContentModel CreateServiceBusMessage(EvolvePaymentRequest cosmosDocument, bool success,
       object additionalInfo, string comments)
      => new()
      {
          EvolveId = cosmosDocument.EvolveId,
          PaymentReference = cosmosDocument.PaymentReference,
          SourceAccount = new SourceAccount()
          {
              AccountNumber = cosmosDocument.SourceAccount.AccountNumber,
              RoutingNumber = cosmosDocument.SourceAccount.RoutingNumber,
              Name = new AccountName()
              {
                  First = cosmosDocument.SourceAccount.Name.First,
                  Last = cosmosDocument.SourceAccount.Name.Last,
                  Company = cosmosDocument.SourceAccount.Name.Company
              },
              AccountType = "S"
          },
          DestinationAccount = new DestinationAccount()
          {
              AccountNumber = cosmosDocument.DestinationAccount.AccountNumber,
              RoutingNumber = cosmosDocument.DestinationAccount.RoutingNumber,
              Name = new AccountName()
              {
                  First = cosmosDocument.DestinationAccount.Name.First,
                  Last = cosmosDocument.DestinationAccount.Name.Last,
                  Company = cosmosDocument.DestinationAccount.Name.Company
              },
              AccountType = "C",
          },
          UltimateDebtor = new UltimateDebtor()
          {
              Name = cosmosDocument.UltimateDebtor?.Name
          },
          CIFNO = cosmosDocument.FintechId,
          SourceCurrency = cosmosDocument.PaymentCurrency,
          DestCurrency = cosmosDocument.PaymentCurrency,
          Status = cosmosDocument.Status,
          ValueDate = cosmosDocument.ValueDate,
          InstructionId = cosmosDocument.InstructionId,
          OriginalInstructionId = cosmosDocument.OrigInstructionId,
          PmtHandler = cosmosDocument.DocumentSubType,
          Amount = cosmosDocument.Amount,
          Success = success,
          DocumentType = cosmosDocument.DocumentType,
          AdditionalInfo = additionalInfo,
          Comments = comments,
          ClientId = cosmosDocument.ClientId,
          MerchantId = cosmosDocument.MerchantId
      };
}