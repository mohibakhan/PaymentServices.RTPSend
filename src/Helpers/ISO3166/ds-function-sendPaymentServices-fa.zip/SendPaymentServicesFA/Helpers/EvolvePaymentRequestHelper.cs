﻿using System;
using Microsoft.Azure.Cosmos;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using Microsoft.Extensions.Options;
using SendPaymentServicesFA.Settings;
using SendPaymentServicesFA.Constants;
using SendPaymentServicesFA.Interface;
using SendPaymentServicesFA.Models.Business;
using SendPaymentServicesFA.Models.Response;
using Evolve.Digital.Shared.Models.Payments;
using Evolve.Digital.Core.Utilities.Datetime;

namespace SendPaymentServicesFA.Helpers;

public class EvolvePaymentRequestHelper : IEvolvePaymentRequestHelper
{
    private readonly AppSettings _appSettings;

    public EvolvePaymentRequestHelper(IOptions<AppSettings> appSettings)
    {
        _appSettings = appSettings.Value;
    }

    /// <summary>
    /// Helper method to convert <see cref="BasicPaymentRequest"/> to <see cref="EvolvePaymentRequest"/>
    /// </summary>
    /// <param name="basicPaymentRequest"></param>
    /// <returns></returns>
    public EvolvePaymentRequest ConvertBasicToEvolveRequest(BasicPaymentRequest basicPaymentRequest, IHeaderDictionary headers, string documentSubType)
    {
        // Initialize and Add required fields
        var evolvePaymentRequest = new EvolvePaymentRequest()
        {
            Type = PaymentRequestConstants.CreatePaymentTypePush,
            AchOptions = PaymentRequestConstants.CreatePaymentAchOptions,
            PaymentCurrency = PaymentRequestConstants.CreatePaymentDefaultCurrency,
            ValueDate = DateTimeExtensions.ToCosmosDateTime(DateTime.Now),
            TranCode = _appSettings.RTP_SEND_TRAN_CODE,
            CreatedTimeStamp = DateTimeExtensions.ToCosmosDateTime(DateTime.Now),
            DocumentType = PaymentRequestConstants.DocumentType,
            DocumentSubType = documentSubType,
            ClientId = headers["x-client-id"].ToString(),
            MerchantId = headers["x-merchant-id"].ToString(),
            Status = RequestStatus.RECEIVED.ToString(),
            Stage = RequestStage.RTP_API.ToString()
        };

        evolvePaymentRequest.StatusHistory.Add(new StatusHistory()
        {
            Stage = RequestStage.RTP_API.ToString(),
            StatusDate = DateTimeExtensions.ToCosmosDateTime(DateTime.Now),
            Status = EnumHelper.GetEnumValue(RequestStatus.RECEIVED),
        });

        // Map basic payment fields to evolve payment request fields
        evolvePaymentRequest.PaymentReference = basicPaymentRequest.PaymentReference.Trim();
        evolvePaymentRequest.SourceAccountId = basicPaymentRequest.SourceAccountId;
        evolvePaymentRequest.Amount = basicPaymentRequest.Amount;
        evolvePaymentRequest.UltimateDebtor = basicPaymentRequest.UltimateDebtor ?? null;

        #region sourceAccount
        if (basicPaymentRequest.SourceAccount != null)
        {
            evolvePaymentRequest.SourceAccount = new SourceAccount();
            evolvePaymentRequest.SourceAccount.Name = new AccountName();
            evolvePaymentRequest.SourceAccount.DebtorIdOther = basicPaymentRequest.SourceAccount.DebtorIdOther;

            evolvePaymentRequest.SourceAccount.AccountNumber = basicPaymentRequest.SourceAccount.AccountNumber.Trim();
            evolvePaymentRequest.SourceAccount.RoutingNumber = basicPaymentRequest.SourceAccount.RoutingNumber.Trim();
            evolvePaymentRequest.SourceAccount.AccountType = basicPaymentRequest.SourceAccount.AccountType;
            evolvePaymentRequest.SourceAccount.DebtorBankMemberID = basicPaymentRequest.SourceAccount.DebtorBankMemberID;
            evolvePaymentRequest.SourceAccount.Name.First = basicPaymentRequest.SourceAccount.Name.First;
            evolvePaymentRequest.SourceAccount.Name.Last = basicPaymentRequest.SourceAccount.Name.Last;
            evolvePaymentRequest.SourceAccount.Name.Company = basicPaymentRequest.SourceAccount.Name.Company;
        }
        #endregion

        #region destinationAccount
        if (basicPaymentRequest.DestinationAccount != null)
        {
            evolvePaymentRequest.DestinationAccount = new DestinationAccount();
            evolvePaymentRequest.DestinationAccount.Name = new AccountName();
            evolvePaymentRequest.DestinationAccount.Address = new Address();
            evolvePaymentRequest.DestinationAccount.CreditorIdOther = basicPaymentRequest.DestinationAccount.CreditorIdOther;

            evolvePaymentRequest.DestinationAccount.AccountNumber = basicPaymentRequest.DestinationAccount.AccountNumber.Trim();
            evolvePaymentRequest.DestinationAccount.RoutingNumber = basicPaymentRequest.DestinationAccount.RoutingNumber.Trim();
            evolvePaymentRequest.DestinationAccount.AccountType = basicPaymentRequest.DestinationAccount.AccountType;
            evolvePaymentRequest.DestinationAccount.PhoneNumber = basicPaymentRequest.DestinationAccount.PhoneNumber;
            evolvePaymentRequest.DestinationAccount.CreditorAgentTCHMemberID = basicPaymentRequest.DestinationAccount.CreditorAgentTCHMemberID;
            evolvePaymentRequest.DestinationAccount.Name.First = basicPaymentRequest.DestinationAccount.Name.First;
            evolvePaymentRequest.DestinationAccount.Name.Last = basicPaymentRequest.DestinationAccount.Name.Last;
            evolvePaymentRequest.DestinationAccount.Name.Company = basicPaymentRequest.DestinationAccount.Name.Company;
            evolvePaymentRequest.DestinationAccount.Address.City = basicPaymentRequest.DestinationAccount.Address.City;
            evolvePaymentRequest.DestinationAccount.Address.CountryISOCode = basicPaymentRequest.DestinationAccount.Address.CountryISOCode;
            evolvePaymentRequest.DestinationAccount.Address.PostalCode = basicPaymentRequest.DestinationAccount.Address.PostalCode;
            evolvePaymentRequest.DestinationAccount.Address.StateCode = basicPaymentRequest.DestinationAccount.Address.StateCode;
            evolvePaymentRequest.DestinationAccount.Address.AddressLines = basicPaymentRequest.DestinationAccount.Address.AddressLines;
        }

        #endregion

        if(basicPaymentRequest.SoftDescriptor != null)
        {
            evolvePaymentRequest.SoftDescriptor = basicPaymentRequest.SoftDescriptor;
        }

        return evolvePaymentRequest;
    }

    /// <summary>
    /// Help method to convert <see cref="EvolvePaymentRequest"/> to <see cref="BusinessEvolvePaymentRequest"/>
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    /// <exception cref="NotImplementedException"></exception>
    public BusinessEvolvePaymentRequest ConvertToBusinessDocument(EvolvePaymentRequest request)
    {
        var statusHistory = new List<BusinessRequestStatusHistory>();

        foreach (var requestStatus in request.StatusHistory)
            statusHistory.Add(new BusinessRequestStatusHistory() { StatusDate = requestStatus.StatusDate, Status = requestStatus.Status });

        return new BusinessEvolvePaymentRequest()
        {
            EvolveId = request.EvolveId,
            Amount = request.Amount,
            CreatedTimeStamp = request.CreatedTimeStamp,
            ModifiedTimeStamp = request.ModifiedTimeStamp,
            TabaPayReferenceId = request.TabaPayReferenceId,
            TabaPayTransactionId = request.TabaPayTransactionId,
            PaymentCurrency = request.PaymentCurrency,
            ClientId = request.ClientId,
            MerchantId = request.MerchantId,
            GluId = request.GluId,
            FintechId = request.FintechId,
            FboAccountName = request.FboAccountName,
            FboAccountNumber = request.FboAccountNumber,
            TaxId = request.TaxId,
            UserIsBusiness = request.UserIsBusiness,
            ValueDate = request.ValueDate,
            PaymentReference = request.PaymentReference,
            SourceAccount = request.SourceAccount,
            DestinationAccount = request.DestinationAccount,
            UltimateDebtor = request.UltimateDebtor,
            StatusHistory = statusHistory
        };
    }

    /// <summary>
    /// Checks whether status has a given value for additional Information
    /// </summary>
    /// <param name="statusHistory"></param>
    /// <param name="additionalInfo"></param>
    /// <returns></returns>
    /// <exception cref="NotImplementedException"></exception>
    public bool ContainsAdditionalInfo(List<StatusHistory> statusHistory, string additionalInfo)
    {
        foreach (var statusHistoryItem in statusHistory)
        {
            if (statusHistoryItem.AddInfo != null && statusHistoryItem.Status == RequestStatus.FAILED.ToString())
            {
                if (statusHistoryItem.AddInfo.ToString().Contains(additionalInfo))
                    return true;
                return false;
            }
        }
        return false;
    }


    public static List<PatchOperation> GetStatusPatchOperation(RequestStage stage, RequestStatus status, object additionalInfo = null)
    {
        string text = DateTime.UtcNow.ToCosmosDateTime();
        return new List<PatchOperation>()
        {
                PatchOperation.Add($"/statusHistory/-",
                new StatusHistory
                {
                    StatusDate = text,
                    Stage = stage.ToString(),
                    Status = status.ToString(),
                    AddInfo = additionalInfo
                }),
                PatchOperation.Replace($"/stage",stage.ToString()),
                PatchOperation.Replace($"/status",status.ToString()),
                PatchOperation.Replace($"/modifiedTimeStamp",text)
        };
    }

    public static List<PatchOperation> SetAccountLookupPatchoperation(PartnerLedgerResponse partnerLedgerResponse)
    {
        return new List<PatchOperation>()
        {
                PatchOperation.Replace($"/fboAccount",partnerLedgerResponse.FboAccount),
                PatchOperation.Replace($"/fboAccountName",partnerLedgerResponse.FboAccountName),
                PatchOperation.Replace($"/fintechId",partnerLedgerResponse.CifNo),
                PatchOperation.Replace($"/taxId",partnerLedgerResponse.TaxId),
                PatchOperation.Replace($"/userIsBusiness",partnerLedgerResponse.IsBusinessUser)
        };
    }

    public static List<PatchOperation> GetTabaPaypatchoperation(string tabaPayTransactionId, string tabaPayReferenceId, string instructionId)
    {
        return new List<PatchOperation>()
        {
                PatchOperation.Replace($"/tabaPayTransactionId",tabaPayTransactionId),
                PatchOperation.Replace($"/tabaPayReferenceId",tabaPayReferenceId),
                PatchOperation.Replace($"/instructionId",instructionId)
        };
    }

    public static List<PatchOperation> GetGluIdUpdatePatchOperation(string gluId, string gludId_s, string gludId_d)
    {
        return new List<PatchOperation>()
        {
                PatchOperation.Replace($"/gluId",gluId),
                PatchOperation.Replace($"/gluId_s",gludId_s),
                PatchOperation.Replace($"/gluId_d",gludId_d)
        };
    }

    public static List<PatchOperation> GetNodeUpdatePatchOperation(string nodeName, string nodeValue)
    {
        return new List<PatchOperation>()
        {
                PatchOperation.Replace($"/{nodeName}",nodeValue)
        };
    }

    public static List<PatchOperation> GetVolPayResponsePatchOperation(VolPayResponse resp)
    {
        return new List<PatchOperation>()
        {
                PatchOperation.Replace($"/volOrgPmtRef",resp.PmtDtls.OrgPmtRef),
                PatchOperation.Replace($"/volBkAssgndRef",resp.PmtDtls.BkAssgndRef),
                PatchOperation.Replace($"/volStsCd",resp.PmtDtls.StsCd)
        };
    }
}