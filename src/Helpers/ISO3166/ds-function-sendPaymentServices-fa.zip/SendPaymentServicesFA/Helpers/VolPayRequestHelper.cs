﻿using System;
using System.Collections.Generic;
using SendPaymentServicesFA.Models.Request;
using Evolve.Digital.Shared.Models.Payments;
using Cdtr = SendPaymentServicesFA.Models.Request.Cdtr;
using Dbtr = SendPaymentServicesFA.Models.Request.Dbtr;
using PmtDtl = SendPaymentServicesFA.Models.Request.PmtDtl;
using DbtrAgt = SendPaymentServicesFA.Models.Request.DbtrAgt;
using DbtrAcct = SendPaymentServicesFA.Models.Request.DbtrAcct;

namespace SendPaymentServicesFA.Helpers;

public static class VolPayRequestHelper
{
    public static VolPayRequest ConvertEvolveToVolPayRequest(EvolvePaymentRequest request)
    {
        return new VolPayRequest
        {
            PmtDtls = new List<PmtDtl>
            {
                new PmtDtl
                {
                    ValueDt =  DateTime.UtcNow.ToString("yyyy-MM-dd"),
                    Amt = request?.Amount,
                    Ccy = "USD",
                    MsgTyp = "Customer Credit Transfer",
                    LclInstrm = "STANDARD",
                    CtgyPurp = (request.UserIsBusiness) ? "BUSINESS": "CONSUMER",
                    ReqExDt = DateTime.UtcNow.ToString("yyyy-MM-dd"),
                    TxId =  Guid.Parse(request.EvolveId).ToString("N") // Remove dashes from guid to be under 35 characters //ToString("N") gives 32 chars
                    //UETR = request.EvolveId
                }
            },
            Dbtr = new List<Dbtr>
            {
                new Dbtr
                {
                    AcctNm = request?.SourceAccount?.Name.ToString(),
                }
            },
            DbtrAcct = new List<DbtrAcct>
            {
                new DbtrAcct
                {
                    AcctNb = request?.SourceAccount?.AccountNumber
                }
            },
            DbtrAgt = new List<DbtrAgt>
            {
                new DbtrAgt
                {
                    MmbId = request?.SourceAccount?.RoutingNumber
                }
            },
            //InitiatingParty = new List<InitiatingParty>
            //{
            //    new InitiatingParty
            //    {
            //        Nm = "Nm",
            //        OthrId = "021000018",
            //    }
            //},
            CdtrAgt = new List<CdtrAgtModel>
            {
                new CdtrAgtModel
                {
                    CdtrAgtMmbID = request?.DestinationAccount?.RoutingNumber
                }
            },
            Cdtr = new List<Cdtr>
            {
                new Cdtr
                {
                    CdtrNm = request?.DestinationAccount?.Name?.ToString(),
                }
            },
            CdtrAcct = new List<CdtrAcctModel>
            {
                new CdtrAcctModel
                {
                    CdtrAcct = request?.DestinationAccount?.AccountNumber,
                    OthrId = request.DestinationAccount?.CreditorIdOther,
                    PrxyId = "128989hkjfnkdjf" //TO DO
                }
            }
        };
    }
}