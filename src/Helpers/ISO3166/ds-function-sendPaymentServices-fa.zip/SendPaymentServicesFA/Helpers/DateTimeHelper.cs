﻿using System;

namespace SendPaymentServicesFA.Helpers;

public static class DateTimeHelper
{
    public static string GetIsoTimestamp() => DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ");
}
