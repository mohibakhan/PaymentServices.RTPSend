﻿using System;
using System.Linq;
using System.Text;
using Microsoft.AspNetCore.Http;
using System.Security.Cryptography;
using System.Diagnostics.CodeAnalysis;
using Microsoft.ApplicationInsights.DataContracts;

namespace SendPaymentServicesFA.Helpers;

public interface IProblemHelper
{
    /// <summary>
    /// Returns trace id for the current context
    /// </summary>
    /// <param name="httpContext"></param>
    /// <returns></returns>
    string GetTraceId(HttpContext httpContext);

    /// <summary>
    /// Generates a short alphanumeric string
    /// </summary>
    /// <param name="traceId">The trace Id of the current request</param>
    /// <returns>A short alphanumeric suitable for use as a
    /// 'Problem.ReferenceCode'
    /// </returns>
    string GenerateReferenceCode(string traceId);

    /// <summary>
    /// Generates a short alphanumeric string.
    /// </summary>
    /// <returns>A short alphanumeric suitable for use as a
    /// 'Problem.ReferenceCode'
    /// </returns>
    string GenerateReferenceCode();
}

/// <summary>
///     Default implementation of the `IProblemHelper` interface.
/// </summary>
public class ProblemHelper : IProblemHelper
{
    private const string Base32AllowedCharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
    private static int ReferenceCodeLength = 6;

    [ExcludeFromCodeCoverage]
    public string GetTraceId(HttpContext httpContext)
    {
        return httpContext.Features.Get<RequestTelemetry>()?.Context.Operation.Id;
    }

    public string GenerateReferenceCode(string traceId)
    {
        // if trace id is not available, return a general purpose code.
        if (string.IsNullOrWhiteSpace(traceId))
            return GenerateReferenceCode();

        // hash and convert the trace id to base 32
        using var sha256 = SHA256.Create();
        var traceBytes = Encoding.UTF8.GetBytes(traceId);
        var hashBytes = sha256.ComputeHash(traceBytes);
        var hashString = ToBase32String(hashBytes);

        // take first 6 characters of hash string
        return hashString[..6];
    }

    public string GenerateReferenceCode()
    {
        using (var gen = RandomNumberGenerator.Create())
        {
            var code = new char[ReferenceCodeLength];

            for (int i = 0; i < code.Length; i++)
            {
                var index = RandomNumberGenerator.GetInt32(0, Base32AllowedCharacters.Length);
                code[i] = Base32AllowedCharacters[index];
            }

            return new String(code);
        }
    }

    /// <summary>
    ///     Convert a byte array to a base 32 string.
    /// </summary>
    /// <param name="input">Byte array data to encode.</param>
    /// <returns>A base 32 string.</returns>
    private static string ToBase32String(byte[] input)
    {
        var bits = input
            .Select(b => Convert.ToString(b, 2).PadLeft(8, '0'))
            .Aggregate((a, b) => a + b)
            .PadRight((int)(Math.Ceiling((input.Length * 8) / 5d) * 5), '0');

        return Enumerable
            .Range(0, bits.Length / 5)
            .Select(i => Base32AllowedCharacters.Substring(Convert.ToInt32(bits.Substring(i * 5, 5), 2), 1))
            .Aggregate((a, b) => a + b);
    }
}