﻿using Evolve.Digital.Shared.Models.Payments;

namespace SendPaymentServicesFA.Helpers;

public static class EnumHelper
{
    public static string GetEnumValue(RequestStatus requestState) => requestState.ToString();
}
