﻿using System;
using SendPaymentServicesFA.Constants;
using SendPaymentServicesFA.Models.Request;
using Evolve.Digital.Shared.Models.Payments;

namespace SendPaymentServicesFA.Helpers;

public static class TabaPayRequestHelper
{
    public static TabaPayRequest ConvertEvolveToTabaPayRequest(EvolvePaymentRequest evolvePaymentRequest)
    {
        var tabaPayRequest = new TabaPayRequest()
        {
            ReferenceId = GenerateReferenceId(),
            Type = evolvePaymentRequest.Type ?? PaymentRequestConstants.CreatePaymentTypePush,
            AchOptions = evolvePaymentRequest.AchOptions ?? PaymentRequestConstants.CreatePaymentAchOptions,
            Amount = evolvePaymentRequest.Amount,
            Currency = evolvePaymentRequest.PaymentCurrency ?? PaymentRequestConstants.CreatePaymentDefaultCurrency,
            Corresponding = new Corresponding()
            {
                Name = evolvePaymentRequest.SourceAccount.Name,
                Address = (TabapayAddress)evolvePaymentRequest.SourceAccount.Address,
                AccountNumber = evolvePaymentRequest.SourceAccount.AccountNumber,
                SourceOfFunds = "Credit Account",
            },
            Accounts = new Accounts()
            {
                SourceAccountId = "yuEAY8eEwGafmufciZBrEQ", //TO DO
                DestinationAccount = new Account()
                {
                    Bank = new Bank()
                    {
                        AccountNumber = evolvePaymentRequest.DestinationAccount.AccountNumber,
                        RoutingNumber = evolvePaymentRequest.DestinationAccount.RoutingNumber,
                        AccountType = evolvePaymentRequest.DestinationAccount.AccountType,
                    },
                    Owner = new Owner()
                    {
                        Name = evolvePaymentRequest.DestinationAccount.Name,
                        Address = (TabapayAddress)evolvePaymentRequest.DestinationAccount.Address,
                        Phone = new Phone()
                        {
                            Number = evolvePaymentRequest.DestinationAccount.PhoneNumber
                        }
                    }
                }
            }
        };
        
        if(evolvePaymentRequest.SoftDescriptor != null)
        {
            tabaPayRequest.SoftDescriptor = new Models.Request.SoftDescriptor()
            {
                Name = evolvePaymentRequest.SoftDescriptor.Name,
                Address = new TabapayAddress()
                {
                    Line1 = evolvePaymentRequest.SoftDescriptor.Address.AddressLines[0],
                    City = evolvePaymentRequest.SoftDescriptor.Address.City,
                    County = evolvePaymentRequest.SoftDescriptor.Address.County,
                    State = evolvePaymentRequest.SoftDescriptor.Address.StateCode,
                    Zipcode = evolvePaymentRequest.SoftDescriptor.Address.PostalCode,
                    Country = evolvePaymentRequest.SoftDescriptor.Address.CountryISOCode,
                },
                Email = evolvePaymentRequest.SoftDescriptor.Email,
                Phone = new Phone()
                {
                    Number = evolvePaymentRequest.SoftDescriptor.Phone.Number
                }
            };
        }

        return tabaPayRequest;
    }

    private static string GenerateReferenceId()
    {
        string _allowedChars = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ0123456789";
        var randNum = new Random();
        var chars = new char[15];
        for (int i = 0; i < 15; i++)
            chars[i] = _allowedChars[(int)((_allowedChars.Length) * randNum.NextDouble())];
        return new string(chars);
    }
}


