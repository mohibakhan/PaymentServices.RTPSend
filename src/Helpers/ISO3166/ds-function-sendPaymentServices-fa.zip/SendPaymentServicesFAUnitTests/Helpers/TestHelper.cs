﻿using Moq;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;

namespace SendPaymentServicesFAUnitTests.Helpers
{
    public class TestHelper
    {
        public static Mock<HttpRequest> MockPostHttpRequest(string jsonBody, IHeaderDictionary headers)
        {
            return MockPostHttpRequest(jsonBody, HttpMethod.Post, headers);
        }

        private static Mock<HttpRequest> MockPostHttpRequest(string jsonBody, HttpMethod httpMethod, IHeaderDictionary headers = null)
        {
            var memoryStream = new MemoryStream();
            var streamWriter = new StreamWriter(memoryStream);
            streamWriter.Write(jsonBody);
            streamWriter.Flush();
            memoryStream.Position = 0;
            var mockedHttpRequest = new Mock<HttpRequest>();
            mockedHttpRequest.Setup(x => x.Method).Returns(httpMethod.ToString());
            mockedHttpRequest.Setup(x => x.Body).Returns(memoryStream);
            mockedHttpRequest.SetupGet(e => e.Headers).Returns(headers);
            return mockedHttpRequest;
        }

        public static HttpRequest MockGetHttpRequest(HttpMethod method, Dictionary<string, StringValues> queryParams, string body = null, Dictionary<string, StringValues> headers = null)
        {
            var httpRequest = new Mock<HttpRequest>();
            httpRequest.SetupGet(r => r.Method).Returns(method.ToString());
            httpRequest.SetupGet(e => e.Query).Returns(new QueryCollection(queryParams));

            if (body != null)
            {
                var ms = new MemoryStream();
                var writer = new StreamWriter(ms);
                writer.Write(body);
                writer.Flush();
                ms.Position = 0;
                httpRequest.Setup(reqMock => reqMock.Body).Returns(ms);
            }

            httpRequest.SetupGet(e => e.Headers).Returns(new HeaderDictionary(headers));
            return httpRequest.Object;
        }
    }
}