﻿using Moq;
using Xunit;
using System.Net;
using Newtonsoft.Json;
using FluentValidation;
using Evolve.Digital.Testing;
using FluentValidation.Results;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using SendPaymentServicesFA.Helpers;
using SendPaymentServicesFA.Functions;
using SendPaymentServicesFA.Interface;
using Evolve.Digital.Shared.Models.Payments;
using SendPaymentServicesFA.Exceptions.Core;
using SendPaymentServicesFA.Models.Business;
using SendPaymentServicesFA.Models.Response;
using SendPaymentServicesFA.Services.Facade;
using SendPaymentServicesFAUnitTests.Helpers;
using SendPaymentServicesFA.Interface.Adapters;
using SendPaymentServicesFA.Interface.Services;
using SendPaymentServicesFA.Interface.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SendPaymentServicesFAUnitTests;

[TestClass]
public class CreatePaymentTests : BaseUnitTest
{
    private readonly Mock<ILogger<CreatePayment>> _logger = new();
    private readonly Mock<IPrefundLedgerService> _rtpLedgerService = new();
    private readonly Mock<IPaymentCosmosDBAdapter> _paymentCosmosDBService = new();
    private readonly Mock<IEvolvePaymentRequestHelper> _evolvePaymentRequestHelper = new();
    private readonly Mock<IApiUserConfigCosmosAdapter> _apiUserConfigRepository = new();
    private readonly Mock<IPartnerLedgerRepository> _partnerLedgerRepository = new();
    private readonly Mock<IValidator<BasicPaymentRequest>> _validator = new();
    private readonly Mock<IPartnerLedgerService> _partnerLedgerService = new();
    private readonly Mock<IProblemHelper> _problemHelper = new();
    private readonly Mock<IPreRtpChecksFacade> _facade = new();
    private readonly CreatePayment _sut;


    IHeaderDictionary headers = new HeaderDictionary
        {
            { "x-client-id", "Bm0RU8eASGfSxLYJjsG73Q" },
            { "x-merchant-id", "1000" },
            {"ocp-apim-subscription-key" ,"sdlkf" }
        };

    public CreatePaymentTests()
    {
        _problemHelper
           .Setup(e => e.GenerateReferenceCode(It.IsAny<string>()))
           .Returns("TESTCODE");

        _problemHelper
            .Setup(e => e.GetTraceId(It.IsAny<HttpContext>()))
            .Returns("test-trace");

        _sut = new CreatePayment(_paymentCosmosDBService.Object, _evolvePaymentRequestHelper.Object,
             _apiUserConfigRepository.Object, _validator.Object, _problemHelper.Object,
            _logger.Object, _facade.Object);
    }

    /// <summary>
    /// Happy path testing
    /// </summary>
    [Fact]
    public async Task CreatePayment_01_R202()
    {
        // Arrange
        var requestBody = GetJsonData<BasicPaymentRequest>("request.json");
        var expectectedResponse = GetJsonData<CreatePaymentResponse>("expectedResponse.json");
        var apiUserConfigResponse = GetJsonData<ApiUserConfigResponse>("apiUserConfigResponse.json");

        //var httpRequest = TestHelper.GetMockHttpPost(requestBody);
        var httpRequest = TestHelper.MockPostHttpRequest(JsonConvert.SerializeObject(requestBody), headers).Object;

        var prefundResponse = new PrefundLedgerResponse { GluId = "d847855b-e12d-479a-a761-7bcc8df09b7f" };

        var expectedEvolveRequest = GetJsonData<EvolvePaymentRequest>("evolveRequest.json");

        _evolvePaymentRequestHelper
            .Setup(e => e.ConvertBasicToEvolveRequest(It.IsAny<BasicPaymentRequest>(), It.IsAny<HeaderDictionary>(), "TabaPay"))
            .Returns(expectedEvolveRequest);
        _paymentCosmosDBService
            .Setup(p => p.FindIfItemDuplicateAsync(It.IsAny<string>(), It.IsAny<HeaderDictionary>()))
            .ReturnsAsync(false);
        _paymentCosmosDBService
            .Setup(p => p.CreateItemAsync(It.IsAny<EvolvePaymentRequest>()))
            .ReturnsAsync(expectedEvolveRequest);
        _paymentCosmosDBService
            .Setup(p => p.UpdateItemAsync(It.IsAny<EvolvePaymentRequest>()))
            .ReturnsAsync(expectedEvolveRequest);
        _apiUserConfigRepository
           .Setup(x => x.GetApiUserConfigAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
           .ReturnsAsync(apiUserConfigResponse);
        _partnerLedgerRepository
            .Setup(p => p.PartnerLedgerVAccountLookup(It.IsAny<string>()))
            .ReturnsAsync(new PartnerLedgerResponse() { CifNo = "DAA0850", FboAccount = "9900001458", FboAccountName = "DAVE INC", VAccountNumber = "269154750799" });
        _partnerLedgerService
            .Setup(p => p.PartnerLedgerLookupLA(It.IsAny<string>()))
            .ReturnsAsync(new PartnerLedgerResponse() { CifNo = "DAA0850", FboAccount = "9900001458", FboAccountName = "DAVE INC", VAccountNumber = "269154750799" });
        _rtpLedgerService
            .Setup(r => r.SendFraudSanctionsCheck(It.IsAny<BusinessEvolvePaymentRequest>()))
            .ReturnsAsync(new HttpResponseMessage() { StatusCode = HttpStatusCode.OK, Content = new StringContent(JsonConvert.SerializeObject(prefundResponse)) });
        _validator.Setup(validator => validator.ValidateAsync(It.IsAny<BasicPaymentRequest>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new ValidationResult());

        // Act
        var response = TestableActionResult.Create(await _sut.Run(httpRequest));
        var actualBody = await response.Content.ReadAsAsync<CreatePaymentResponse>();

        // Assert
        AreEqual(HttpStatusCode.Accepted, response.StatusCode);
        AreEqual(expectectedResponse, actualBody);

    }

    /// <summary>
    /// This test ensures that if incoming request is null a Bad Request response is sent to user
    /// </summary>
    [Fact]
    public async Task CreatePayment_02_R400()
    {
        // Arrange
        var requestBody = GetJsonData<BasicPaymentRequest>("request.json");
        var expectedResponse = GetJsonData<Problem>("expectedResponse.json");
        var httpRequest = TestHelper.MockPostHttpRequest(JsonConvert.SerializeObject(requestBody), headers).Object;

        // Act
        var response = TestableActionResult.Create(await _sut.Run(httpRequest));
        var actualBody = await response.Content.ReadAsAsync<Problem>();

        // Assert
        AreEqual(HttpStatusCode.BadRequest, response.StatusCode);
        AreEqual(expectedResponse, actualBody);
    }

    /// <summary>
    /// 
    /// </summary>
    [Fact]
    public async Task CreatePayment_03_R500()
    {
        // Arrange
        var requestBody = GetJsonData<object>("request.json");
        var httpRequest = TestHelper.MockPostHttpRequest(JsonConvert.SerializeObject(requestBody), headers).Object;
        var expectedResponse = GetJsonData<Problem>("expectedResponse.json");

        // Act
        var response = TestableActionResult.Create(await _sut.Run(httpRequest));
        var actualBody = await response.Content.ReadAsAsync<Problem>();

        // Assert
        AreEqual(HttpStatusCode.InternalServerError, response.StatusCode);
        AreEqual(expectedResponse, actualBody);
    }

    /// <summary>
    /// Send a 409 Conflict if requests exists
    /// </summary>
    [Fact]
    public async Task CreatePayment_04_R409()
    {
        // Arrange
        var requestBody = GetJsonData<BasicPaymentRequest>("request.json");
        var expectedResponse = GetJsonData<Problem>("expectedResponse.json");
        var httpRequest = TestHelper.MockPostHttpRequest(JsonConvert.SerializeObject(requestBody), headers).Object;
        var expectedEvolveRequest = GetJsonData<EvolvePaymentRequest>("evolveRequest.json");
        var apiUserConfigResponse = GetJsonData<ApiUserConfigResponse>("apiUserConfigResponse.json");

        _evolvePaymentRequestHelper
            .Setup(e => e.ConvertBasicToEvolveRequest(It.IsAny<BasicPaymentRequest>(), It.IsAny<HeaderDictionary>(), "documentSubType"))
            .Returns(expectedEvolveRequest);

        _paymentCosmosDBService
            .Setup(p => p.FindIfItemDuplicateAsync(It.IsAny<string>(), It.IsAny<HeaderDictionary>()))
            .ReturnsAsync(true);

        _apiUserConfigRepository
           .Setup(x => x.GetApiUserConfigAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
           .ReturnsAsync(apiUserConfigResponse);

        _validator.Setup(validator => validator.ValidateAsync(It.IsAny<BasicPaymentRequest>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new ValidationResult());

        // Act
        var response = TestableActionResult.Create(await _sut.Run(httpRequest));
        var actualBody = await response.Content.ReadAsAsync<Problem>();

        // Assert
        AreEqual(HttpStatusCode.Conflict, response.StatusCode);
        AreEqual(expectedResponse, actualBody);
    }
}