﻿using Moq;
using Xunit;
using System.Net;
using Newtonsoft.Json;
using Evolve.Digital.Testing;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using SendPaymentServicesFA.Helpers;
using SendPaymentServicesFA.Settings;
using SendPaymentServicesFA.Functions;
using SendPaymentServicesFA.Models.Request;
using SendPaymentServicesFA.Models.Business;
using SendPaymentServicesFA.Models.Response;
using Evolve.Digital.Shared.Models.Payments;
using SendPaymentServicesFAUnitTests.Helpers;
using SendPaymentServicesFA.Interface.Adapters;
using SendPaymentServicesFA.Interface.Services;
using SendPaymentServicesFA.Interface.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SendPaymentServicesFAUnitTests;

[TestClass]
public class ValidatePaymentTests : BaseUnitTest
{
    private readonly Mock<ILogger<ValidatePayment>> _logger = new();
    private readonly Mock<IPaymentCosmosDBAdapter> _paymentCosmosDBService = new();
    private readonly Mock<IApiUserConfigRepository> _apiUserConfigRepository = new();
    private readonly Mock<IProblemHelper> _problemHelper = new();
    private readonly Mock<IPrefundEventProcessor> _prefundEventProcessor = new();


    private readonly ValidatePayment _sut;

    public ValidatePaymentTests()
    {
        _problemHelper
          .Setup(e => e.GenerateReferenceCode(It.IsAny<string>()))
          .Returns("TESTCODE");

        _problemHelper
            .Setup(e => e.GetTraceId(It.IsAny<HttpContext>()))
            .Returns("test-trace");

        _sut = new ValidatePayment(_paymentCosmosDBService.Object, _apiUserConfigRepository.Object, _prefundEventProcessor.Object, _logger.Object);
    }

    /// <summary>
    /// Happy path testing
    /// </summary>
    [Fact]
    public async Task ValidatePayment_01_R200()
    {
        // Arrange
        var requestBody = GetJsonData<RtpValidateEvent>("request.json");
        var cosmosItemList = GetJsonData<List<EvolvePaymentRequest>>("evolvePaymentItem.json");
        var cosmosBusinessItem = GetJsonData<BusinessEvolvePaymentRequest>("evolveBusinessRequest.json");
        var tabaPayPaymentRequest = GetJsonData<TabapayPaymentRequest>("tabaPayPaymentRequest.json");
        var expectedResponse = true;
        var apiUserConfigResponse = GetJsonData<ApiUserConfigResponse>("apiUserConfigResponse.json");
        var @event = GetJsonData<RtpValidateEvent>("rtpValidateEvent.json");

        var httpRequest = TestHelper.MockPostHttpRequest(JsonConvert.SerializeObject(requestBody), null).Object;

        _paymentCosmosDBService
            .Setup(p => p.FindAllItemsAsync(It.IsAny<string>())).
            ReturnsAsync(cosmosItemList);

        _paymentCosmosDBService
            .Setup(p => p.UpdateItemAsync(It.IsAny<EvolvePaymentRequest>()))
            .ReturnsAsync(cosmosItemList.FirstOrDefault);

        _apiUserConfigRepository
            .Setup(p => p.GetApiUserConfigAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(apiUserConfigResponse);

        _prefundEventProcessor
            .Setup(p => p.ProcessEventAsync(It.IsAny<RtpValidateEvent>(), It.IsAny<EvolvePaymentRequest>()))
            .ReturnsAsync(true);

        AppSettings app = new() { SERVICE_BUS_QUEUE_NAME = "QueueNameMocked" };

        // Act
        var response = TestableActionResult.Create(await _sut.Run(httpRequest));
        response.Content.Headers.ContentType = MediaTypeHeaderValue.Parse("application/json");
        var actualBody = await response.Content.ReadAsStringAsync();

        // Assert
        AreEqual(HttpStatusCode.OK, response.StatusCode);
        AreEqual(expectedResponse.ToString().ToLower(), actualBody);
    }
}